"use server"

import { and, count, desc, eq, ilike, or } from "drizzle-orm"
import { headers } from "next/headers"
import { revalidatePath } from "next/cache"
import { verifyPassword } from "better-auth/crypto"
import { auth } from "@/lib/auth"
import { db } from "@/lib/db"
import { account, campaignAuditLog, campaignDispatches, campaignEvents, campaignLeaders, campaignPermissions, campaignTasks, campaignVoters, campaignWhatsappSettings, user } from "@/lib/db/schema"

async function getUserId() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) throw new Error("Unauthorized")
  return session.user.id
}

async function requireRole(roles: string[]) {
  const userId = await getUserId()
  const [currentUser] = await db.select({ role: user.role }).from(user).where(eq(user.id, userId)).limit(1)
  if (!currentUser || !roles.includes(currentUser.role)) throw new Error("Forbidden")
  return userId
}

const adminResources = ["dashboard", "voters", "calendar", "tasks", "dispatch", "search", "projections", "users"] as const

export async function verifyAdminPassword(password: string) {
  const adminId = await requireRole(["admin"])
  if (!password || password.length < 8) throw new Error("Informe uma senha válida")
  const [credential] = await db.select({ hash: account.password }).from(account).where(and(eq(account.userId, adminId), eq(account.providerId, "credential"))).limit(1)
  if (!credential?.hash || !(await verifyPassword({ password, hash: credential.hash }))) throw new Error("Senha administrativa incorreta")
  return true
}

export async function listAdminAccess() {
  const adminId = await requireRole(["admin"])
  const users = await db.select({ id: user.id, name: user.name, email: user.email, role: user.role }).from(user).orderBy(user.name)
  const permissions = await db.select().from(campaignPermissions)
  return { users, permissions, adminId }
}

export async function setUserResourceAccess(userId: string, resource: string, enabled: boolean) {
  const adminId = await requireRole(["admin"])
  if (!adminResources.includes(resource as (typeof adminResources)[number])) throw new Error("Guia inválida")
  if (userId === adminId) throw new Error("O administrador principal sempre mantém acesso")
  if (enabled) {
    await db.insert(campaignPermissions).values({ id: crypto.randomUUID(), userId, grantedBy: adminId, resource }).onConflictDoNothing()
  } else {
    await db.delete(campaignPermissions).where(and(eq(campaignPermissions.userId, userId), eq(campaignPermissions.resource, resource)))
  }
  await audit(adminId, enabled ? "grant" : "revoke", "permission", userId, { resource })
  revalidatePath("/dashboard/admin")
}

export async function canAccessResource(resource: string) {
  const userId = await getUserId()
  const [currentUser] = await db.select({ role: user.role }).from(user).where(eq(user.id, userId)).limit(1)
  if (currentUser?.role === "admin") return true
  const [permission] = await db.select({ id: campaignPermissions.id }).from(campaignPermissions).where(and(eq(campaignPermissions.userId, userId), eq(campaignPermissions.resource, resource))).limit(1)
  return Boolean(permission)
}

async function audit(userId: string, action: string, entity: string, entityId?: string, metadata: Record<string, unknown> = {}) {
  await db.insert(campaignAuditLog).values({ id: crypto.randomUUID(), userId, action, entity, entityId, metadata })
}

export async function listVoters(query?: string) {
  const userId = await getUserId()
  const term = query?.trim()
  return db.select().from(campaignVoters).where(term ? and(eq(campaignVoters.userId, userId), or(ilike(campaignVoters.name, `%${term}%`), ilike(campaignVoters.cpf, `%${term}%`), ilike(campaignVoters.email, `%${term}%`))) : eq(campaignVoters.userId, userId)).orderBy(desc(campaignVoters.createdAt))
}

export async function upsertVoter(input: typeof campaignVoters.$inferInsert) {
  const userId = await getUserId()
  await db.insert(campaignVoters).values({ ...input, userId }).onConflictDoUpdate({ target: campaignVoters.id, set: { ...input, userId, updatedAt: new Date() } })
  await audit(userId, "upsert", "voter", input.id)
  revalidatePath("/dashboard/voters")
  revalidatePath("/dashboard")
}

export async function removeVoter(id: string) {
  const userId = await getUserId()
  await db.delete(campaignVoters).where(and(eq(campaignVoters.id, id), eq(campaignVoters.userId, userId)))
  await audit(userId, "delete", "voter", id)
  revalidatePath("/dashboard/voters")
  revalidatePath("/dashboard")
}

export async function listEvents() {
  const userId = await getUserId()
  return db.select().from(campaignEvents).where(eq(campaignEvents.userId, userId)).orderBy(desc(campaignEvents.date))
}

export async function upsertEvent(input: typeof campaignEvents.$inferInsert) {
  const userId = await getUserId()
  await db.insert(campaignEvents).values({ ...input, userId }).onConflictDoUpdate({ target: campaignEvents.id, set: { ...input, userId, updatedAt: new Date() } })
  revalidatePath("/dashboard/calendar")
  revalidatePath("/dashboard")
}

export async function removeEvent(id: string) {
  const userId = await getUserId()
  await db.delete(campaignEvents).where(and(eq(campaignEvents.id, id), eq(campaignEvents.userId, userId)))
  revalidatePath("/dashboard/calendar")
}

export async function listTasks() {
  const userId = await getUserId()
  return db.select().from(campaignTasks).where(eq(campaignTasks.userId, userId)).orderBy(desc(campaignTasks.createdAt))
}

export async function upsertTask(input: typeof campaignTasks.$inferInsert) {
  const userId = await getUserId()
  await db.insert(campaignTasks).values({ ...input, userId }).onConflictDoUpdate({ target: campaignTasks.id, set: { ...input, userId, updatedAt: new Date() } })
  revalidatePath("/dashboard/tasks")
}

export async function removeTask(id: string) {
  const userId = await getUserId()
  await db.delete(campaignTasks).where(and(eq(campaignTasks.id, id), eq(campaignTasks.userId, userId)))
  await audit(userId, "delete", "task", id)
  revalidatePath("/dashboard/tasks")
}

export async function listAuditLog() {
  const userId = await requireRole(["admin", "coordinator"])
  return db.select().from(campaignAuditLog).where(eq(campaignAuditLog.userId, userId)).orderBy(desc(campaignAuditLog.createdAt)).limit(100)
}

export async function getCapacityProjection() {
  const userId = await getUserId()
  const [leaders, voters] = await Promise.all([
    db.select({ region: campaignLeaders.region, total: count() }).from(campaignLeaders).where(eq(campaignLeaders.userId, userId)).groupBy(campaignLeaders.region),
    db.select({ region: campaignVoters.zone, total: count() }).from(campaignVoters).where(eq(campaignVoters.userId, userId)).groupBy(campaignVoters.zone),
  ])
  const regions = new Map<string, { leaders: number; contacts: number }>()
  for (const item of leaders) { const key = item.region || "Sem região"; regions.set(key, { leaders: Number(item.total), contacts: regions.get(key)?.contacts ?? 0 }) }
  for (const item of voters) { const key = item.region || "Sem região"; regions.set(key, { leaders: regions.get(key)?.leaders ?? 0, contacts: Number(item.total) }) }
  return [...regions.entries()].map(([region, values]) => {
    const base = Math.max(values.leaders * 18, Math.round(values.contacts * 0.12))
    return { region, leaders: values.leaders, contacts: values.contacts, conservative: Math.round(base * 0.65), base: Math.round(base), expansion: Math.round(base * 1.35) }
  }).sort((a, b) => b.base - a.base)
}

export async function listLeaders(region?: string) {
  const userId = await getUserId()
  return db.select().from(campaignLeaders).where(region ? and(eq(campaignLeaders.userId, userId), eq(campaignLeaders.region, region)) : eq(campaignLeaders.userId, userId)).orderBy(campaignLeaders.region, campaignLeaders.name)
}

export async function listDispatchContacts() {
  const userId = await getUserId()
  const [leaders, voters] = await Promise.all([
    db.select({ id: campaignLeaders.id, name: campaignLeaders.name, phone: campaignLeaders.phone, region: campaignLeaders.region, type: campaignLeaders.status }).from(campaignLeaders).where(eq(campaignLeaders.userId, userId)).orderBy(campaignLeaders.name),
    db.select({ id: campaignVoters.id, name: campaignVoters.name, phone: campaignVoters.phone, region: campaignVoters.zone, type: campaignVoters.categoria }).from(campaignVoters).where(and(eq(campaignVoters.userId, userId), eq(campaignVoters.status, "active"))).orderBy(campaignVoters.name),
  ])
  return [...leaders.map((item) => ({ ...item, type: "leader" as const })), ...voters.filter((item) => item.phone).map((item) => ({ ...item, type: "voter" as const, phone: item.phone as string, region: item.region ?? "Sem região" }))]
}

export async function getWhatsappSettings() {
  const userId = await getUserId()
  const [settings] = await db.select().from(campaignWhatsappSettings).where(eq(campaignWhatsappSettings.userId, userId)).limit(1)
  return settings ?? null
}

export async function saveWhatsappSettings(input: { senderName: string; senderPhone: string; apiEnabled: boolean }) {
  const userId = await getUserId()
  const id = `whatsapp-${userId}`
  await db.insert(campaignWhatsappSettings).values({ id, userId, ...input, updatedAt: new Date() }).onConflictDoUpdate({ target: campaignWhatsappSettings.id, set: { ...input, updatedAt: new Date() } })
  await audit(userId, "upsert", "whatsapp_settings", id)
  revalidatePath("/dashboard/dispatch")
}

export async function upsertLeader(input: Omit<typeof campaignLeaders.$inferInsert, "userId">) {
  const userId = await getUserId()
  await db.insert(campaignLeaders).values({ ...input, userId }).onConflictDoUpdate({ target: campaignLeaders.id, set: { ...input, userId, updatedAt: new Date() } })
  await audit(userId, "upsert", "leader", input.id, { region: input.region })
  revalidatePath("/dashboard/dispatch")
}

export async function removeLeader(id: string) {
  const userId = await requireRole(["admin", "coordinator"])
  await db.delete(campaignLeaders).where(and(eq(campaignLeaders.id, id), eq(campaignLeaders.userId, userId)))
  await audit(userId, "delete", "leader", id)
  revalidatePath("/dashboard/dispatch")
}

export async function listDispatches() {
  const userId = await getUserId()
  return db.select().from(campaignDispatches).where(eq(campaignDispatches.userId, userId)).orderBy(desc(campaignDispatches.createdAt)).limit(100)
}

export async function createDispatch(input: { recipientId: string; recipientType: "leader" | "voter"; demand: string; channel: "whatsapp_web" | "whatsapp_api"; scheduledFor?: Date }) {
  const userId = await getUserId()
  const contacts = await listDispatchContacts()
  const recipient = contacts.find((contact) => contact.id === input.recipientId && contact.type === input.recipientType)
  if (!recipient) throw new Error("Destinatário não encontrado")
  const id = crypto.randomUUID()
  await db.insert(campaignDispatches).values({ id, userId, leaderId: input.recipientType === "leader" ? recipient.id : null, recipientType: input.recipientType, recipientId: recipient.id, recipientName: recipient.name, recipientPhone: recipient.phone, region: recipient.region, demand: input.demand, channel: input.channel, scheduledFor: input.scheduledFor, status: input.scheduledFor ? "scheduled" : "queued" })
  await audit(userId, "create", "dispatch", id, { channel: input.channel, recipientType: input.recipientType, region: recipient.region })
  revalidatePath("/dashboard/dispatch")
  return { id, recipient: { name: recipient.name, phone: recipient.phone, region: recipient.region } }
}

export async function markDispatchSent(id: string, providerMessageId?: string) {
  const userId = await getUserId()
  await db.update(campaignDispatches).set({ status: "sent", sentAt: new Date(), providerMessageId, updatedAt: new Date() }).where(and(eq(campaignDispatches.id, id), eq(campaignDispatches.userId, userId)))
  await audit(userId, "send", "dispatch", id)
  revalidatePath("/dashboard/dispatch")
}

export async function sendDispatchViaWhatsAppApi(id: string) {
  const userId = await getUserId()
  const [dispatch] = await db.select().from(campaignDispatches).where(and(eq(campaignDispatches.id, id), eq(campaignDispatches.userId, userId))).limit(1)
  if (!dispatch) throw new Error("Disparo não encontrado")
  const token = process.env.WHATSAPP_ACCESS_TOKEN
  const phoneNumberId = process.env.WHATSAPP_PHONE_NUMBER_ID
  if (!token || !phoneNumberId) throw new Error("API oficial do WhatsApp não configurada")
  const response = await fetch(`https://graph.facebook.com/v22.0/${phoneNumberId}/messages`, { method: "POST", headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" }, body: JSON.stringify({ messaging_product: "whatsapp", to: dispatch.recipientPhone.replace(/\\D/g, ""), type: "text", text: { body: dispatch.demand } }) })
  if (!response.ok) { const error = await response.text(); await db.update(campaignDispatches).set({ status: "failed", errorMessage: error, updatedAt: new Date() }).where(eq(campaignDispatches.id, id)); throw new Error("Falha no envio pela API oficial") }
  const result = await response.json() as { messages?: Array<{ id?: string }> }
  await markDispatchSent(id, result.messages?.[0]?.id)
  return result
}
