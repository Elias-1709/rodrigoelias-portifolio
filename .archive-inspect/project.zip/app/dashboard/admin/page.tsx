import { listAdminAccess } from "@/app/actions/campaign"
import { AdminAccessPanel } from "@/components/admin-access-panel"
import { auth } from "@/lib/auth"
import { headers } from "next/headers"
import { redirect } from "next/navigation"

export default async function AdminPage() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) redirect("/")
  try {
    const data = await listAdminAccess()
    return <AdminAccessPanel {...data} />
  } catch {
    redirect("/dashboard")
  }
}
