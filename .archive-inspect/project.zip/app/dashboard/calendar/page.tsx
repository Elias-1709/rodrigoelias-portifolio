"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/components/auth-provider"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardNav } from "@/components/dashboard-nav"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Plus, CalendarDays, List, Calendar } from "lucide-react"
import type { Event } from "@/lib/mock-data"
import { getEvents, saveEvent, deleteEvent as deleteEventFromStorage } from "@/lib/storage"
import { EventForm } from "@/components/event-form"
import { EventCard } from "@/components/event-card"
import { CalendarGrid } from "@/components/calendar-grid"
import { useToast } from "@/hooks/use-toast"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"

export default function CalendarPage() {
  const { user, isLoading } = useAuth()
  const router = useRouter()
  const { toast } = useToast()

  const [events, setEvents] = useState<Event[]>([])
  const [formOpen, setFormOpen] = useState(false)
  const [editingEvent, setEditingEvent] = useState<Event | undefined>()
  const [activeTab, setActiveTab] = useState("all")
  const [viewMode, setViewMode] = useState<"calendar" | "list">("calendar")
  const [selectedDate, setSelectedDate] = useState<Date | null>(null)
  const [dateDialogOpen, setDateDialogOpen] = useState(false)

  useEffect(() => {
    if (!isLoading && !user) {
      router.push("/")
    }
  }, [user, isLoading, router])

  useEffect(() => {
    if (typeof window !== "undefined") {
      setEvents(getEvents())
    }
  }, [])

  const handleSubmit = (eventData: Partial<Event>) => {
    if (editingEvent) {
      const updatedEvent = { ...editingEvent, ...eventData }
      saveEvent(updatedEvent)
      setEvents(getEvents())
      toast({
        title: "Evento atualizado",
        description: "O evento foi atualizado com sucesso.",
      })
    } else {
      const newEvent: Event = {
        ...eventData,
        id: Date.now().toString(),
      } as Event
      saveEvent(newEvent)
      setEvents(getEvents())
      toast({
        title: "Evento criado",
        description: "O evento foi adicionado à agenda.",
      })
    }
    setEditingEvent(undefined)
  }

  const handleEdit = (event: Event) => {
    setEditingEvent(event)
    setFormOpen(true)
  }

  const handleDelete = (eventId: string) => {
    if (confirm("Tem certeza que deseja excluir este evento?")) {
      deleteEventFromStorage(eventId)
      setEvents(getEvents())
      toast({
        title: "Evento excluído",
        description: "O evento foi removido da agenda.",
      })
    }
  }

  const handleEventClick = (event: Event) => {
    setEditingEvent(event)
    setFormOpen(true)
  }

  const handleDateClick = (date: Date) => {
    setSelectedDate(date)
    setDateDialogOpen(true)
  }

  const handleCreateEventForDate = () => {
    if (selectedDate) {
      const year = selectedDate.getFullYear()
      const month = String(selectedDate.getMonth() + 1).padStart(2, "0")
      const day = String(selectedDate.getDate()).padStart(2, "0")
      const dateStr = `${year}-${month}-${day}`

      setEditingEvent({
        id: "",
        title: "",
        type: "meeting",
        date: dateStr,
        time: "09:00",
        location: "",
        description: "",
        attendees: 0,
        status: "scheduled",
      })
      setDateDialogOpen(false)
      setFormOpen(true)
    }
  }

  const getEventsForSelectedDate = () => {
    if (!selectedDate) return []
    const year = selectedDate.getFullYear()
    const month = String(selectedDate.getMonth() + 1).padStart(2, "0")
    const day = String(selectedDate.getDate()).padStart(2, "0")
    const dateStr = `${year}-${month}-${day}`
    return events.filter((event) => event.date === dateStr)
  }

  const filterEvents = (status?: Event["status"]) => {
    const sortedEvents = [...events].sort((a, b) => {
      const dateA = new Date(`${a.date}T${a.time}`)
      const dateB = new Date(`${b.date}T${b.time}`)
      return dateA.getTime() - dateB.getTime()
    })

    if (status) {
      return sortedEvents.filter((e) => e.status === status)
    }
    return sortedEvents
  }

  const upcomingEvents = filterEvents("scheduled")
  const completedEvents = filterEvents("completed")
  const allEvents = filterEvents()

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-muted-foreground">Carregando...</p>
      </div>
    )
  }

  if (!user) {
    return null
  }

  return (
    <div className="min-h-screen flex flex-col">
      <DashboardHeader />
      <div className="flex flex-1">
        <aside className="hidden md:block w-64 border-r bg-muted/30">
          <DashboardNav />
        </aside>
        <main className="flex-1 p-6 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-3xl font-bold tracking-tight">Agenda da Campanha</h2>
  <p className="text-muted-foreground">Gerencie os eventos e atividades</p>
  <div className="mt-4 flex flex-wrap gap-2 text-xs"><span className="rounded-full bg-primary/10 px-3 py-1.5 font-semibold text-primary">{upcomingEvents.length} próximos</span><span className="rounded-full bg-muted px-3 py-1.5 font-semibold text-muted-foreground">{events.length} no total</span></div>
  </div>
            <div className="flex gap-2">
              <div className="border rounded-lg p-1 flex gap-1">
                <Button
                  variant={viewMode === "calendar" ? "secondary" : "ghost"}
                  size="sm"
                  onClick={() => setViewMode("calendar")}
                >
                  <Calendar className="h-4 w-4" />
                </Button>
                <Button
                  variant={viewMode === "list" ? "secondary" : "ghost"}
                  size="sm"
                  onClick={() => setViewMode("list")}
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
              <Button
                onClick={() => {
                  setEditingEvent(undefined)
                  setFormOpen(true)
                }}
              >
                <Plus className="h-4 w-4 mr-2" />
                Novo Evento
              </Button>
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-3">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium">Próximos Eventos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{upcomingEvents.length}</div>
                <p className="text-xs text-muted-foreground mt-1">Agendados</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium">Eventos Realizados</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{completedEvents.length}</div>
                <p className="text-xs text-muted-foreground mt-1">Concluídos</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium">Total de Eventos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{events.length}</div>
                <p className="text-xs text-muted-foreground mt-1">Na agenda</p>
              </CardContent>
            </Card>
          </div>

          {viewMode === "calendar" ? (
            <CalendarGrid events={events} onEventClick={handleEventClick} onDateClick={handleDateClick} />
          ) : (
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList>
                <TabsTrigger value="all">Todos</TabsTrigger>
                <TabsTrigger value="upcoming">Próximos</TabsTrigger>
                <TabsTrigger value="completed">Realizados</TabsTrigger>
              </TabsList>

              <TabsContent value="all" className="space-y-4">
                {allEvents.length === 0 ? (
                  <Card>
                    <CardContent className="flex flex-col items-center justify-center py-10">
                      <CalendarDays className="h-12 w-12 text-muted-foreground mb-4" />
                      <p className="text-muted-foreground">Nenhum evento cadastrado</p>
                    </CardContent>
                  </Card>
                ) : (
                  <div className="grid gap-4 md:grid-cols-2">
                    {allEvents.map((event) => (
                      <EventCard key={event.id} event={event} onEdit={handleEdit} onDelete={handleDelete} />
                    ))}
                  </div>
                )}
              </TabsContent>

              <TabsContent value="upcoming" className="space-y-4">
                {upcomingEvents.length === 0 ? (
                  <Card>
                    <CardContent className="flex flex-col items-center justify-center py-10">
                      <CalendarDays className="h-12 w-12 text-muted-foreground mb-4" />
                      <p className="text-muted-foreground">Nenhum evento agendado</p>
                    </CardContent>
                  </Card>
                ) : (
                  <div className="grid gap-4 md:grid-cols-2">
                    {upcomingEvents.map((event) => (
                      <EventCard key={event.id} event={event} onEdit={handleEdit} onDelete={handleDelete} />
                    ))}
                  </div>
                )}
              </TabsContent>

              <TabsContent value="completed" className="space-y-4">
                {completedEvents.length === 0 ? (
                  <Card>
                    <CardContent className="flex flex-col items-center justify-center py-10">
                      <CalendarDays className="h-12 w-12 text-muted-foreground mb-4" />
                      <p className="text-muted-foreground">Nenhum evento realizado ainda</p>
                    </CardContent>
                  </Card>
                ) : (
                  <div className="grid gap-4 md:grid-cols-2">
                    {completedEvents.map((event) => (
                      <EventCard key={event.id} event={event} onEdit={handleEdit} onDelete={handleDelete} />
                    ))}
                  </div>
                )}
              </TabsContent>
            </Tabs>
          )}
        </main>
      </div>

      <EventForm event={editingEvent} open={formOpen} onOpenChange={setFormOpen} onSubmit={handleSubmit} />

      <Dialog open={dateDialogOpen} onOpenChange={setDateDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {selectedDate?.toLocaleDateString("pt-BR", { day: "numeric", month: "long", year: "numeric" })}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {getEventsForSelectedDate().length > 0 ? (
              <div className="space-y-2">
                <h4 className="font-medium">Eventos nesta data:</h4>
                {getEventsForSelectedDate().map((event) => (
                  <div
                    key={event.id}
                    className="p-3 rounded-lg border hover:bg-accent cursor-pointer"
                    onClick={() => {
                      handleEventClick(event)
                      setDateDialogOpen(false)
                    }}
                  >
                    <div className="font-medium">{event.title}</div>
                    <div className="text-sm text-muted-foreground">
                      {event.time} - {event.location}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground text-center py-4">Nenhum evento nesta data</p>
            )}
            <Button onClick={handleCreateEventForDate} className="w-full">
              <Plus className="h-4 w-4 mr-2" />
              Criar Evento Nesta Data
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
