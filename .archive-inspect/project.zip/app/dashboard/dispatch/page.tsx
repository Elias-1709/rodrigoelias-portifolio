import { getWhatsappSettings, listDispatchContacts, listDispatches, listLeaders } from "@/app/actions/campaign"
import { DispatchCenter } from "@/components/dispatch-center"
import { auth } from "@/lib/auth"
import { headers } from "next/headers"
import { redirect } from "next/navigation"

export default async function DispatchPage() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) redirect("/")
  const [leaders, dispatches, contacts, whatsapp] = await Promise.all([listLeaders(), listDispatches(), listDispatchContacts(), getWhatsappSettings()])
  return <DispatchCenter initialLeaders={leaders} initialDispatches={dispatches} initialContacts={contacts} initialWhatsapp={whatsapp} />
}
