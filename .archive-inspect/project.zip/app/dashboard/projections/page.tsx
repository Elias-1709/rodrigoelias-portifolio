import { getCapacityProjection } from "@/app/actions/campaign"
import { headers } from "next/headers"
import { redirect } from "next/navigation"
import { auth } from "@/lib/auth"
import { CapacityProjection } from "@/components/capacity-projection"

export default async function ProjectionsPage() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) redirect("/")
  const data = await getCapacityProjection()
  return <CapacityProjection data={data} />
}
