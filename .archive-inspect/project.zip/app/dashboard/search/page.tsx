"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/components/auth-provider"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardNav } from "@/components/dashboard-nav"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Search, Filter, X, Download, Eye } from "lucide-react"
import { mockVoters, type Voter } from "@/lib/mock-data"
import { VoterDetailDialog } from "@/components/voter-detail-dialog"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

interface SearchFilters {
  name: string
  cpf: string
  zone: string
  section: string
  status: string
  city: string
  state: string
  tag: string
}

export default function SearchPage() {
  const { user, isLoading } = useAuth()
  const router = useRouter()

  const [voters] = useState<Voter[]>(mockVoters)
  const [filters, setFilters] = useState<SearchFilters>({
    name: "",
    cpf: "",
    zone: "",
    section: "",
    status: "",
    city: "",
    state: "",
    tag: "",
  })
  const [selectedVoter, setSelectedVoter] = useState<Voter | null>(null)
  const [detailDialogOpen, setDetailDialogOpen] = useState(false)

  useEffect(() => {
    if (!isLoading && !user) {
      router.push("/")
    }
  }, [user, isLoading, router])

  const filteredVoters = voters.filter((voter) => {
    if (filters.name && !voter.name.toLowerCase().includes(filters.name.toLowerCase())) return false
    if (filters.cpf && !voter.cpf.includes(filters.cpf)) return false
    if (filters.zone && voter.zone !== filters.zone) return false
    if (filters.section && voter.section !== filters.section) return false
    if (filters.status && voter.status !== filters.status) return false
    if (filters.city && !voter.address.city.toLowerCase().includes(filters.city.toLowerCase())) return false
    if (filters.state && voter.address.state !== filters.state.toUpperCase()) return false
    if (filters.tag && !voter.tags.some((tag) => tag.toLowerCase().includes(filters.tag.toLowerCase()))) return false
    return true
  })

  const clearFilters = () => {
    setFilters({
      name: "",
      cpf: "",
      zone: "",
      section: "",
      status: "",
      city: "",
      state: "",
      tag: "",
    })
  }

  const exportToCSV = () => {
    const headers = ["Nome", "CPF", "Email", "Telefone", "Zona", "Seção", "Status", "Cidade", "Estado"]
    const rows = filteredVoters.map((voter) => [
      voter.name,
      voter.cpf,
      voter.email,
      voter.phone,
      voter.zone,
      voter.section,
      voter.status,
      voter.address.city,
      voter.address.state,
    ])

    const csvContent = [headers, ...rows].map((row) => row.join(",")).join("\n")
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
    const link = document.createElement("a")
    const url = URL.createObjectURL(blob)

    link.setAttribute("href", url)
    link.setAttribute("download", `eleitores_${new Date().toISOString().split("T")[0]}.csv`)
    link.style.visibility = "hidden"
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  const handleViewDetail = (voter: Voter) => {
    setSelectedVoter(voter)
    setDetailDialogOpen(true)
  }

  const statusColors = {
    active: "bg-green-100 text-green-700",
    pending: "bg-yellow-100 text-yellow-700",
    inactive: "bg-gray-100 text-gray-700",
  }

  const statusLabels = {
    active: "Ativo",
    pending: "Pendente",
    inactive: "Inativo",
  }

  const activeFiltersCount = Object.values(filters).filter((value) => value !== "").length

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-muted-foreground">Carregando...</p>
      </div>
    )
  }

  if (!user) {
    return null
  }

  return (
    <div className="min-h-screen flex flex-col">
      <DashboardHeader />
      <div className="flex flex-1">
        <aside className="hidden md:block w-64 border-r bg-muted/30">
          <DashboardNav />
        </aside>
        <main className="flex-1 p-6 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-3xl font-bold tracking-tight">Busca Avançada</h2>
              <p className="text-muted-foreground">Encontre eleitores com filtros personalizados</p>
            </div>
          </div>

          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Filter className="h-5 w-5" />
                    Filtros de Busca
                    {activeFiltersCount > 0 && (
                      <Badge variant="secondary" className="ml-2">
                        {activeFiltersCount} ativo{activeFiltersCount > 1 ? "s" : ""}
                      </Badge>
                    )}
                  </CardTitle>
                  <CardDescription>Use os campos abaixo para refinar sua busca</CardDescription>
                </div>
                {activeFiltersCount > 0 && (
                  <Button variant="ghost" size="sm" onClick={clearFilters}>
                    <X className="h-4 w-4 mr-2" />
                    Limpar Filtros
                  </Button>
                )}
              </div>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible defaultValue="basic">
                <AccordionItem value="basic">
                  <AccordionTrigger>Informações Básicas</AccordionTrigger>
                  <AccordionContent>
                    <div className="grid gap-4 md:grid-cols-3 pt-4">
                      <div className="space-y-2">
                        <Label htmlFor="filter-name">Nome</Label>
                        <Input
                          id="filter-name"
                          placeholder="Buscar por nome..."
                          value={filters.name}
                          onChange={(e) => setFilters({ ...filters, name: e.target.value })}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="filter-cpf">CPF</Label>
                        <Input
                          id="filter-cpf"
                          placeholder="000.000.000-00"
                          value={filters.cpf}
                          onChange={(e) => setFilters({ ...filters, cpf: e.target.value })}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="filter-status">Status</Label>
                        <Select
                          value={filters.status}
                          onValueChange={(value) => setFilters({ ...filters, status: value })}
                        >
                          <SelectTrigger id="filter-status">
                            <SelectValue placeholder="Todos" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="all">Todos</SelectItem>
                            <SelectItem value="active">Ativo</SelectItem>
                            <SelectItem value="pending">Pendente</SelectItem>
                            <SelectItem value="inactive">Inativo</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="location">
                  <AccordionTrigger>Localização</AccordionTrigger>
                  <AccordionContent>
                    <div className="grid gap-4 md:grid-cols-3 pt-4">
                      <div className="space-y-2">
                        <Label htmlFor="filter-city">Cidade</Label>
                        <Input
                          id="filter-city"
                          placeholder="Buscar por cidade..."
                          value={filters.city}
                          onChange={(e) => setFilters({ ...filters, city: e.target.value })}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="filter-state">Estado</Label>
                        <Input
                          id="filter-state"
                          placeholder="SP"
                          maxLength={2}
                          value={filters.state}
                          onChange={(e) => setFilters({ ...filters, state: e.target.value.toUpperCase() })}
                        />
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="electoral">
                  <AccordionTrigger>Informações Eleitorais</AccordionTrigger>
                  <AccordionContent>
                    <div className="grid gap-4 md:grid-cols-3 pt-4">
                      <div className="space-y-2">
                        <Label htmlFor="filter-zone">Zona Eleitoral</Label>
                        <Input
                          id="filter-zone"
                          placeholder="001"
                          value={filters.zone}
                          onChange={(e) => setFilters({ ...filters, zone: e.target.value })}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="filter-section">Seção</Label>
                        <Input
                          id="filter-section"
                          placeholder="0123"
                          value={filters.section}
                          onChange={(e) => setFilters({ ...filters, section: e.target.value })}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="filter-tag">Tag</Label>
                        <Input
                          id="filter-tag"
                          placeholder="Buscar por tag..."
                          value={filters.tag}
                          onChange={(e) => setFilters({ ...filters, tag: e.target.value })}
                        />
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Search className="h-5 w-5" />
                    Resultados da Busca
                  </CardTitle>
                  <CardDescription>
                    {filteredVoters.length} eleitor{filteredVoters.length !== 1 ? "es" : ""} encontrado
                    {filteredVoters.length !== 1 ? "s" : ""}
                  </CardDescription>
                </div>
                {filteredVoters.length > 0 && (
                  <Button variant="outline" onClick={exportToCSV}>
                    <Download className="h-4 w-4 mr-2" />
                    Exportar CSV
                  </Button>
                )}
              </div>
            </CardHeader>
            <CardContent>
              {filteredVoters.length === 0 ? (
                <div className="text-center py-10">
                  <Search className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">Nenhum eleitor encontrado com os filtros aplicados</p>
                </div>
              ) : (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Nome</TableHead>
                        <TableHead>CPF</TableHead>
                        <TableHead>Telefone</TableHead>
                        <TableHead>Cidade/Estado</TableHead>
                        <TableHead>Zona/Seção</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Tags</TableHead>
                        <TableHead className="text-right">Ações</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredVoters.map((voter) => (
                        <TableRow key={voter.id}>
                          <TableCell className="font-medium">{voter.name}</TableCell>
                          <TableCell>{voter.cpf}</TableCell>
                          <TableCell>{voter.phone}</TableCell>
                          <TableCell>
                            {voter.address.city}/{voter.address.state}
                          </TableCell>
                          <TableCell>
                            {voter.zone}/{voter.section}
                          </TableCell>
                          <TableCell>
                            <Badge className={statusColors[voter.status]}>{statusLabels[voter.status]}</Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex flex-wrap gap-1">
                              {voter.tags.slice(0, 2).map((tag) => (
                                <Badge key={tag} variant="outline" className="text-xs">
                                  {tag}
                                </Badge>
                              ))}
                              {voter.tags.length > 2 && (
                                <Badge variant="outline" className="text-xs">
                                  +{voter.tags.length - 2}
                                </Badge>
                              )}
                            </div>
                          </TableCell>
                          <TableCell className="text-right">
                            <Button variant="ghost" size="icon" onClick={() => handleViewDetail(voter)}>
                              <Eye className="h-4 w-4" />
                              <span className="sr-only">Ver detalhes</span>
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </main>
      </div>

      <VoterDetailDialog
        voter={selectedVoter}
        open={detailDialogOpen}
        onOpenChange={setDetailDialogOpen}
        onEdit={() => {}}
      />
    </div>
  )
}
