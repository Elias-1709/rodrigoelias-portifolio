"use client"

import { useState } from "react"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardNav } from "@/components/dashboard-nav"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { useTheme } from "@/components/theme-provider"
import { useToast } from "@/hooks/use-toast"
import { Palette } from "lucide-react"

const presetColors = [
  { name: "Azul Político", color: "oklch(0.45 0.19 252)" },
  { name: "Verde", color: "oklch(0.55 0.18 145)" },
  { name: "Vermelho", color: "oklch(0.55 0.22 25)" },
  { name: "Laranja", color: "oklch(0.65 0.20 50)" },
  { name: "Roxo", color: "oklch(0.50 0.20 290)" },
  { name: "Amarelo", color: "oklch(0.75 0.15 95)" },
]

export default function SettingsPage() {
  const { settings, setPrimaryColor } = useTheme()
  const { toast } = useToast()
  const [customColor, setCustomColor] = useState(settings.primaryColor)

  const handleColorChange = (color: string) => {
    setPrimaryColor(color)
    setCustomColor(color)
    toast({
      title: "Cor atualizada",
      description: "A cor primária do sistema foi alterada com sucesso.",
    })
  }

  return (
    <div className="flex min-h-screen">
      <aside className="hidden md:block w-64 border-r">
        <DashboardNav />
      </aside>

      <div className="flex-1">
        <DashboardHeader />
        <main className="p-4 md:p-6 lg:p-8">
          <div className="mx-auto max-w-4xl space-y-6">
            <div>
              <h1 className="text-3xl font-bold tracking-tight">Configurações</h1>
              <p className="text-muted-foreground">Personalize a aparência do sistema de campanha</p>
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Palette className="h-5 w-5" />
                  Cor Primária do Sistema
                </CardTitle>
                <CardDescription>Escolha a cor principal que será usada nos botões, links e destaques</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label>Cores Predefinidas</Label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    {presetColors.map((preset) => (
                      <button
                        key={preset.name}
                        onClick={() => handleColorChange(preset.color)}
                        className="flex items-center gap-3 rounded-lg border p-3 hover:bg-accent transition-colors"
                        style={{
                          borderColor: settings.primaryColor === preset.color ? preset.color : undefined,
                          borderWidth: settings.primaryColor === preset.color ? "2px" : "1px",
                        }}
                      >
                        <div className="h-8 w-8 rounded-md border" style={{ backgroundColor: preset.color }} />
                        <span className="text-sm font-medium">{preset.name}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="custom-color">Cor Personalizada (formato OKLCH)</Label>
                  <div className="flex gap-2">
                    <Input
                      id="custom-color"
                      value={customColor}
                      onChange={(e) => setCustomColor(e.target.value)}
                      placeholder="oklch(0.45 0.19 252)"
                      className="font-mono"
                    />
                    <Button onClick={() => handleColorChange(customColor)}>Aplicar</Button>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Use o formato: oklch(lightness chroma hue). Exemplo: oklch(0.45 0.19 252)
                  </p>
                </div>

                <div className="rounded-lg border p-4 space-y-2">
                  <Label>Visualização</Label>
                  <div className="flex flex-wrap gap-2">
                    <Button>Botão Primário</Button>
                    <Button variant="outline">Botão Secundário</Button>
                    <Button variant="ghost">Botão Ghost</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  )
}
