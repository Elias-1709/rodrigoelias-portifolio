"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/components/auth-provider"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardNav } from "@/components/dashboard-nav"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Plus, Pencil, Trash2, Clock, UserIcon, Flag } from "lucide-react"
import type { Task } from "@/lib/mock-data"
import { getTasks, saveTask, deleteTask as deleteTaskFromStorage } from "@/lib/storage"
import { TaskForm } from "@/components/task-form"
import { useToast } from "@/hooks/use-toast"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"

export default function TasksPage() {
  const { user, isLoading } = useAuth()
  const router = useRouter()
  const { toast } = useToast()

  const [tasks, setTasks] = useState<Task[]>([])
  const [showForm, setShowForm] = useState(false)
  const [editingTask, setEditingTask] = useState<Task | undefined>()
  const [activeTab, setActiveTab] = useState("all")

  useEffect(() => {
    if (!isLoading && !user) {
      router.push("/")
    }
  }, [user, isLoading, router])

  useEffect(() => {
    if (typeof window !== "undefined") {
      setTasks(getTasks())
    }
  }, [])

  const handleSubmit = (taskData: Partial<Task>) => {
    if (editingTask) {
      const updatedTask = { ...editingTask, ...taskData }
      saveTask(updatedTask)
      setTasks(getTasks())
      toast({
        title: "Tarefa atualizada",
        description: "A tarefa foi atualizada com sucesso.",
      })
    } else {
      const newTask: Task = {
        ...taskData,
        id: Date.now().toString(),
        createdAt: new Date().toISOString(),
      } as Task
      saveTask(newTask)
      setTasks(getTasks())
      toast({
        title: "Tarefa criada",
        description: "A tarefa foi criada com sucesso.",
      })
    }
    setShowForm(false)
    setEditingTask(undefined)
  }

  const handleEdit = (task: Task) => {
    setEditingTask(task)
    setShowForm(true)
  }

  const handleDelete = (taskId: string) => {
    if (confirm("Tem certeza que deseja excluir esta tarefa?")) {
      deleteTaskFromStorage(taskId)
      setTasks(getTasks())
      toast({
        title: "Tarefa excluída",
        description: "A tarefa foi removida do sistema.",
      })
    }
  }

  const handleStatusChange = (task: Task, newStatus: Task["status"]) => {
    const updatedTask = {
      ...task,
      status: newStatus,
      completedAt: newStatus === "completed" ? new Date().toISOString() : undefined,
    }
    saveTask(updatedTask)
    setTasks(getTasks())
    toast({
      title: "Status atualizado",
      description: "O status da tarefa foi alterado.",
    })
  }

  const filteredTasks = activeTab === "all" ? tasks : tasks.filter((task) => task.status === activeTab)
  const completedTasks = tasks.filter((task) => task.status === "completed").length
  const taskProgress = tasks.length ? Math.round((completedTasks / tasks.length) * 100) : 0

  const priorityColors = {
    low: "bg-blue-100 text-blue-700",
    medium: "bg-yellow-100 text-yellow-700",
    high: "bg-red-100 text-red-700",
  }

  const priorityLabels = {
    low: "Baixa",
    medium: "Média",
    high: "Alta",
  }

  const statusColors = {
    todo: "bg-gray-100 text-gray-700",
    "in-progress": "bg-blue-100 text-blue-700",
    completed: "bg-green-100 text-green-700",
  }

  const statusLabels = {
    todo: "A Fazer",
    "in-progress": "Em Progresso",
    completed: "Concluída",
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-muted-foreground">Carregando...</p>
      </div>
    )
  }

  if (!user) {
    return null
  }

  return (
    <div className="min-h-screen flex flex-col">
      <DashboardHeader />
      <div className="flex flex-1">
        <aside className="hidden md:block w-64 border-r bg-muted/30">
          <DashboardNav />
        </aside>
        <main className="flex-1 p-6 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-3xl font-bold tracking-tight">Tarefas</h2>
  <p className="text-muted-foreground">Gerencie as tarefas da campanha</p>
  <div className="mt-4 flex items-center gap-3 text-xs text-muted-foreground"><div className="h-2 w-32 overflow-hidden rounded-full bg-muted"><div className="h-full rounded-full bg-primary transition-all" style={{ width: `${taskProgress}%` }} /></div><span>{taskProgress}% concluído</span></div>
  </div>
            <Button onClick={() => setShowForm(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Nova Tarefa
            </Button>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList>
              <TabsTrigger value="all">Todas ({tasks.length})</TabsTrigger>
              <TabsTrigger value="todo">A Fazer ({tasks.filter((t) => t.status === "todo").length})</TabsTrigger>
              <TabsTrigger value="in-progress">
                Em Progresso ({tasks.filter((t) => t.status === "in-progress").length})
              </TabsTrigger>
              <TabsTrigger value="completed">
                Concluídas ({tasks.filter((t) => t.status === "completed").length})
              </TabsTrigger>
            </TabsList>

            <TabsContent value={activeTab} className="space-y-4">
              {filteredTasks.length === 0 ? (
                <Card>
                  <CardContent className="py-8 text-center text-muted-foreground">
                    Nenhuma tarefa encontrada
                  </CardContent>
                </Card>
              ) : (
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {filteredTasks.map((task) => (
                    <Card key={task.id} className="flex flex-col">
                      <CardHeader>
                        <div className="flex items-start justify-between gap-2">
                          <CardTitle className="text-lg">{task.title}</CardTitle>
                          <Badge className={priorityColors[task.priority]}>
                            <Flag className="h-3 w-3 mr-1" />
                            {priorityLabels[task.priority]}
                          </Badge>
                        </div>
                        <CardDescription className="line-clamp-2">{task.description}</CardDescription>
                      </CardHeader>
                      <CardContent className="flex-1 space-y-4">
                        <div className="space-y-2 text-sm">
                          <div className="flex items-center gap-2 text-muted-foreground">
                            <Clock className="h-4 w-4" />
                            <span>Vencimento: {new Date(task.dueDate).toLocaleDateString("pt-BR")}</span>
                          </div>
                          <div className="flex items-center gap-2 text-muted-foreground">
                            <UserIcon className="h-4 w-4" />
                            <span>{task.assignedToName}</span>
                          </div>
                          {task.relatedTo && (
                            <div className="text-muted-foreground">
                              Relacionado: {task.relatedTo.type === "voter" ? "Eleitor" : "Evento"} -{" "}
                              {task.relatedTo.name}
                            </div>
                          )}
                        </div>

                        <div className="flex items-center gap-2">
                          <Badge className={statusColors[task.status]}>{statusLabels[task.status]}</Badge>
                        </div>

                        <div className="flex items-center gap-2 pt-2 border-t">
                          {task.status !== "completed" && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() =>
                                handleStatusChange(task, task.status === "todo" ? "in-progress" : "completed")
                              }
                            >
                              {task.status === "todo" ? "Iniciar" : "Concluir"}
                            </Button>
                          )}
                          <Button size="sm" variant="ghost" onClick={() => handleEdit(task)}>
                            <Pencil className="h-3 w-3" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleDelete(task.id)}
                            className="text-destructive hover:text-destructive"
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </main>
      </div>

      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingTask ? "Editar Tarefa" : "Nova Tarefa"}</DialogTitle>
            <DialogDescription>
              {editingTask ? "Atualize as informações da tarefa" : "Crie uma nova tarefa para a equipe"}
            </DialogDescription>
          </DialogHeader>
          <TaskForm
            task={editingTask}
            onSubmit={handleSubmit}
            onCancel={() => {
              setShowForm(false)
              setEditingTask(undefined)
            }}
          />
        </DialogContent>
      </Dialog>
    </div>
  )
}
