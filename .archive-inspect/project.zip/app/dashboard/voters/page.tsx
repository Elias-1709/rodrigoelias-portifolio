"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/components/auth-provider"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardNav } from "@/components/dashboard-nav"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Checkbox } from "@/components/ui/checkbox"
import { Plus, Search, Eye, Pencil, Trash2, Filter, MessageCircle, CheckSquare } from "lucide-react"
import type { Voter } from "@/lib/mock-data"
import { getVoters, saveVoter, deleteVoter as deleteVoterFromStorage } from "@/lib/storage"
import { VoterForm } from "@/components/voter-form"
import { VoterDetailDialog } from "@/components/voter-detail-dialog"
import { BulkActionsDialog } from "@/components/bulk-actions-dialog"
import { useToast } from "@/hooks/use-toast"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { openWhatsApp } from "@/lib/whatsapp"

export default function VotersPage() {
  const { user, isLoading } = useAuth()
  const router = useRouter()
  const { toast } = useToast()

  const [voters, setVoters] = useState<Voter[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [filterCategoria, setFilterCategoria] = useState<string>("all")
  const [filterCity, setFilterCity] = useState<string>("all")
  const [filterNeighborhood, setFilterNeighborhood] = useState<string>("all")
  const [showForm, setShowForm] = useState(false)
  const [editingVoter, setEditingVoter] = useState<Voter | undefined>()
  const [selectedVoter, setSelectedVoter] = useState<Voter | null>(null)
  const [detailDialogOpen, setDetailDialogOpen] = useState(false)
  const [selectedVoterIds, setSelectedVoterIds] = useState<Set<string>>(new Set())
  const [bulkActionsOpen, setBulkActionsOpen] = useState(false)

  useEffect(() => {
    if (!isLoading && !user) {
      router.push("/")
    }
  }, [user, isLoading, router])

  useEffect(() => {
    if (typeof window !== "undefined") {
      setVoters(getVoters())
    }
  }, [])

  const filteredVoters = voters.filter((voter) => {
    const matchesSearch =
      voter.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      voter.cpf.includes(searchQuery) ||
      voter.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      voter.phone.includes(searchQuery)

    const matchesCategoria = filterCategoria === "all" || voter.categoria === filterCategoria
    const matchesCity = filterCity === "all" || voter.address.city === filterCity
    const matchesNeighborhood = filterNeighborhood === "all" || voter.address.neighborhood === filterNeighborhood

    return matchesSearch && matchesCategoria && matchesCity && matchesNeighborhood
  })

  const uniqueCities = Array.from(new Set(voters.map((v) => v.address.city))).filter(Boolean)
  const uniqueNeighborhoods = Array.from(new Set(voters.map((v) => v.address.neighborhood))).filter(Boolean)

  const toggleSelectAll = () => {
    if (selectedVoterIds.size === filteredVoters.length) {
      setSelectedVoterIds(new Set())
    } else {
      setSelectedVoterIds(new Set(filteredVoters.map((v) => v.id)))
    }
  }

  const toggleSelectVoter = (voterId: string) => {
    const newSelected = new Set(selectedVoterIds)
    if (newSelected.has(voterId)) {
      newSelected.delete(voterId)
    } else {
      newSelected.add(voterId)
    }
    setSelectedVoterIds(newSelected)
  }

  const handleBulkAction = (action: string, value: any) => {
    const selectedVoters = voters.filter((v) => selectedVoterIds.has(v.id))

    if (action === "status") {
      selectedVoters.forEach((voter) => {
        saveVoter({ ...voter, status: value })
      })
      setVoters(getVoters())
      toast({
        title: "Status atualizado",
        description: `${selectedVoters.length} eleitores tiveram o status alterado.`,
      })
    } else if (action === "categoria") {
      selectedVoters.forEach((voter) => {
        saveVoter({ ...voter, categoria: value })
      })
      setVoters(getVoters())
      toast({
        title: "Categoria atualizada",
        description: `${selectedVoters.length} eleitores tiveram a categoria alterada.`,
      })
    } else if (action === "tags") {
      selectedVoters.forEach((voter) => {
        const newTags = Array.from(new Set([...voter.tags, ...value]))
        saveVoter({ ...voter, tags: newTags })
      })
      setVoters(getVoters())
      toast({
        title: "Tags adicionadas",
        description: `Tags adicionadas a ${selectedVoters.length} eleitores.`,
      })
    } else if (action === "delete") {
      if (confirm(`Tem certeza que deseja excluir ${selectedVoters.length} eleitores?`)) {
        selectedVoters.forEach((voter) => {
          deleteVoterFromStorage(voter.id)
        })
        setVoters(getVoters())
        toast({
          title: "Eleitores excluídos",
          description: `${selectedVoters.length} eleitores foram removidos do sistema.`,
        })
      }
    }

    setSelectedVoterIds(new Set())
  }

  const handleSubmit = (voterData: Partial<Voter>) => {
    if (editingVoter) {
      const updatedVoter = { ...editingVoter, ...voterData }
      saveVoter(updatedVoter)
      setVoters(getVoters())
      toast({
        title: "Eleitor atualizado",
        description: "Os dados do eleitor foram atualizados com sucesso.",
      })
    } else {
      const newVoter: Voter = {
        ...voterData,
        id: Date.now().toString(),
        createdAt: new Date().toISOString(),
        lastContact: new Date().toISOString(),
      } as Voter
      saveVoter(newVoter)
      setVoters(getVoters())
      toast({
        title: "Eleitor cadastrado",
        description: "O eleitor foi cadastrado com sucesso.",
      })
    }
    setShowForm(false)
    setEditingVoter(undefined)
  }

  const handleEdit = (voter: Voter) => {
    setEditingVoter(voter)
    setShowForm(true)
  }

  const handleDelete = (voterId: string) => {
    if (confirm("Tem certeza que deseja excluir este eleitor?")) {
      deleteVoterFromStorage(voterId)
      setVoters(getVoters())
      toast({
        title: "Eleitor excluído",
        description: "O eleitor foi removido do sistema.",
      })
    }
  }

  const handleViewDetail = (voter: Voter) => {
    setSelectedVoter(voter)
    setDetailDialogOpen(true)
  }

  const handleWhatsApp = (voter: Voter) => {
    openWhatsApp(voter.phone, voter.name)
    toast({
      title: "Abrindo WhatsApp",
      description: `Iniciando conversa com ${voter.name}`,
    })
  }

  const statusColors = {
    active: "bg-green-100 text-green-700",
    pending: "bg-yellow-100 text-yellow-700",
    inactive: "bg-gray-100 text-gray-700",
  }

  const statusLabels = {
    active: "Ativo",
    pending: "Pendente",
    inactive: "Inativo",
  }

const categoriaDisplay = {
  NM: "Núcleo mobilizador",
  FL: "Foco local",
  SG: "Segmento estratégico",
  IN: "Interesse inicial",
}

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-muted-foreground">Carregando...</p>
      </div>
    )
  }

  if (!user) {
    return null
  }

  if (showForm) {
    return (
      <div className="min-h-screen flex flex-col">
        <DashboardHeader />
        <div className="flex flex-1">
          <aside className="hidden md:block w-64 border-r bg-muted/30">
            <DashboardNav />
          </aside>
          <main className="flex-1 p-6">
            <div className="max-w-4xl mx-auto">
              <div className="mb-6">
                <h2 className="text-3xl font-bold tracking-tight">
                  {editingVoter ? "Editar Eleitor" : "Novo Eleitor"}
                </h2>
                <p className="text-muted-foreground">
                  {editingVoter ? "Atualize as informações do eleitor" : "Cadastre um novo eleitor no sistema"}
                </p>
              </div>
              <VoterForm
                voter={editingVoter}
                onSubmit={handleSubmit}
                onCancel={() => {
                  setShowForm(false)
                  setEditingVoter(undefined)
                }}
              />
            </div>
          </main>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col">
      <DashboardHeader />
      <div className="flex flex-1">
        <aside className="hidden md:block w-64 border-r bg-muted/30">
          <DashboardNav />
        </aside>
        <main className="flex-1 p-6 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-3xl font-bold tracking-tight">Eleitores</h2>
              <p className="text-muted-foreground">Gerencie os eleitores cadastrados</p>
            </div>
            <div className="flex gap-2">
              {selectedVoterIds.size > 0 && (
                <Button variant="outline" onClick={() => setBulkActionsOpen(true)}>
                  <CheckSquare className="h-4 w-4 mr-2" />
                  Ações ({selectedVoterIds.size})
                </Button>
              )}
              <Button onClick={() => setShowForm(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Novo Eleitor
              </Button>
            </div>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Lista de Eleitores</CardTitle>
              <CardDescription>{voters.length} eleitores cadastrados</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 mb-4">
                <div className="flex items-center gap-2">
                  <div className="relative flex-1">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Buscar por nome, CPF, email ou telefone..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-8"
                    />
                  </div>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  <Filter className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">Filtros:</span>

                  <Select value={filterCategoria} onValueChange={setFilterCategoria}>
                    <SelectTrigger className="w-[140px]">
                      <SelectValue placeholder="Categoria" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todas categorias</SelectItem>
                      <SelectItem value="NM">Núcleo mobilizador</SelectItem>
                      <SelectItem value="FL">Foco local</SelectItem>
                      <SelectItem value="SG">Segmento estratégico</SelectItem>
                      <SelectItem value="IN">Interesse inicial</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select value={filterCity} onValueChange={setFilterCity}>
                    <SelectTrigger className="w-[140px]">
                      <SelectValue placeholder="Município" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos municípios</SelectItem>
                      {uniqueCities.map((city) => (
                        <SelectItem key={city} value={city}>
                          {city}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  <Select value={filterNeighborhood} onValueChange={setFilterNeighborhood}>
                    <SelectTrigger className="w-[140px]">
                      <SelectValue placeholder="Bairro" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos bairros</SelectItem>
                      {uniqueNeighborhoods.map((neighborhood) => (
                        <SelectItem key={neighborhood} value={neighborhood}>
                          {neighborhood}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  {(filterCategoria !== "all" || filterCity !== "all" || filterNeighborhood !== "all") && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setFilterCategoria("all")
                        setFilterCity("all")
                        setFilterNeighborhood("all")
                      }}
                    >
                      Limpar filtros
                    </Button>
                  )}
                </div>
              </div>

              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-12">
                        <Checkbox
                          checked={selectedVoterIds.size === filteredVoters.length && filteredVoters.length > 0}
                          onCheckedChange={toggleSelectAll}
                        />
                      </TableHead>
                      <TableHead>Nome</TableHead>
                      <TableHead>Categoria</TableHead>
                      <TableHead>CPF</TableHead>
                      <TableHead>Telefone</TableHead>
                      <TableHead>Zona/Seção</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredVoters.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={8} className="text-center text-muted-foreground">
                          Nenhum eleitor encontrado
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredVoters.map((voter) => (
                        <TableRow key={voter.id}>
                          <TableCell>
                            <Checkbox
                              checked={selectedVoterIds.has(voter.id)}
                              onCheckedChange={() => toggleSelectVoter(voter.id)}
                            />
                          </TableCell>
                          <TableCell className="font-medium">{voter.name}</TableCell>
                          <TableCell>{categoriaDisplay[voter.categoria]}</TableCell>
                          <TableCell>{voter.cpf}</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              {voter.phone}
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-6 w-6 text-green-600 hover:text-green-700 hover:bg-green-50"
                                onClick={() => handleWhatsApp(voter)}
                                title="Abrir WhatsApp"
                              >
                                <MessageCircle className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                          <TableCell>
                            {voter.zone}/{voter.section}
                          </TableCell>
                          <TableCell>
                            <Badge className={statusColors[voter.status]}>{statusLabels[voter.status]}</Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Button variant="ghost" size="icon" onClick={() => handleViewDetail(voter)}>
                                <Eye className="h-4 w-4" />
                                <span className="sr-only">Ver detalhes</span>
                              </Button>
                              <Button variant="ghost" size="icon" onClick={() => handleEdit(voter)}>
                                <Pencil className="h-4 w-4" />
                                <span className="sr-only">Editar</span>
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleDelete(voter.id)}
                                className="text-destructive hover:text-destructive"
                              >
                                <Trash2 className="h-4 w-4" />
                                <span className="sr-only">Excluir</span>
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>

      <VoterDetailDialog
        voter={selectedVoter}
        open={detailDialogOpen}
        onOpenChange={setDetailDialogOpen}
        onEdit={handleEdit}
      />

      <BulkActionsDialog
        open={bulkActionsOpen}
        onOpenChange={setBulkActionsOpen}
        selectedVoters={voters.filter((v) => selectedVoterIds.has(v.id))}
        onApply={handleBulkAction}
      />
    </div>
  )
}
