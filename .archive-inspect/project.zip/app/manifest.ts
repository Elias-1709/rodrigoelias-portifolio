import type { MetadataRoute } from "next"

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Command Center de Campanha",
    short_name: "Campanha",
    description: "Gestão operacional da campanha",
    start_url: "/",
    display: "standalone",
    background_color: "#f8fafc",
    theme_color: "#0f766e",
    icons: [{ src: "/icon-light-32x32.png", sizes: "32x32", type: "image/png" }],
  }
}
