"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { LoginForm } from "@/components/login-form"
import { useAuth } from "@/components/auth-provider"
import { ShieldCheck } from "lucide-react"

export default function HomePage() {
  const { user, isLoading } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!isLoading && user) router.replace("/dashboard")
  }, [isLoading, router, user])

  if (isLoading) return <div className="grid min-h-screen place-items-center bg-[#f5f8fb] text-[#102b45]"><span className="font-mono text-xs uppercase tracking-[0.2em]">Carregando...</span></div>

  return (
    <main className="min-h-screen bg-[#f5f8fb] text-[#102b45] lg:grid lg:grid-cols-[1.05fr_0.95fr]">
      <section aria-label="Informações da plataforma" className="relative hidden min-h-screen overflow-hidden bg-[#0e2a45] px-12 py-14 text-white lg:flex lg:flex-col lg:justify-center xl:px-24">
        <div className="absolute inset-0 opacity-30 [background-image:linear-gradient(rgba(119,211,220,.12)_1px,transparent_1px),linear-gradient(90deg,rgba(119,211,220,.12)_1px,transparent_1px)] [background-size:44px_44px]" />
        <div className="relative max-w-xl">
          <div className="mb-20 flex items-center gap-3"><div className="flex h-11 w-11 items-center justify-center rounded-sm bg-[#76d5df] text-lg font-black text-[#0e2a45]">EC</div><div><strong className="block text-base tracking-[0.12em]">ELECTORAL</strong><span className="block text-[10px] tracking-[0.3em] text-[#76d5df]">COMMAND CENTER</span></div></div>
          <p className="mb-5 font-mono text-[10px] tracking-[0.25em] text-[#76d5df]">CENTRO DE COMANDO EXECUTIVO</p>
          <h1 className="text-5xl font-semibold leading-[1.08] tracking-[-0.04em] xl:text-7xl">Decisões mais claras.<br /><em className="not-italic text-[#76d5df]">Operações mais fortes.</em></h1>
          <p className="mt-8 max-w-md text-base leading-7 text-white/65">Uma visão integrada para acompanhar o ritmo da campanha, suas equipes e os territórios prioritários.</p>
          <div className="mt-20 flex items-center gap-2 text-xs text-white/50"><ShieldCheck className="h-4 w-4 text-[#76d5df]" /> Ambiente seguro para equipes de campanha</div>
        </div>
      </section>
      <section className="flex min-h-screen items-center justify-center px-6 py-12 sm:px-12">
        <div className="w-full max-w-[390px]"><div className="mb-14 lg:hidden"><strong className="block text-sm tracking-[0.12em]">ELECTORAL</strong><span className="text-[10px] tracking-[0.3em] text-[#18788c]">COMMAND CENTER</span></div><p className="mb-4 font-mono text-[10px] tracking-[0.26em] text-[#18788c]">ACESSO RESTRITO</p><h2 className="text-3xl font-semibold tracking-[-0.03em]">Bem-vindo de volta</h2><p className="mt-3 text-sm text-slate-500">Entre para continuar na sua operação.</p><LoginForm /><p className="mt-8 text-center text-xs text-slate-500">Seus dados são protegidos e tratados com confidencialidade.</p></div>
      </section>
    </main>
  )
}
