"use client"

import { createContext, useContext, useEffect, useState, type ReactNode } from "react"
import { useSession, signOut as authSignOut } from "@/lib/auth-client"
import type { User } from "@/lib/mock-data"

interface AuthContextType { user: User | null; setUser: (user: User | null) => void; isLoading: boolean; signOut: () => Promise<void> }
const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const { data: session, isPending } = useSession()
  const [user, setUserState] = useState<User | null>(null)

  useEffect(() => {
    if (session?.user) setUserState({ id: session.user.id, name: session.user.name, email: session.user.email, role: ((session.user as { role?: User["role"] }).role ?? "operator") as User["role"] })
    else if (!isPending) setUserState(null)
  }, [session, isPending])

  const setUser = (newUser: User | null) => setUserState(newUser)
  const signOut = async () => { await authSignOut(); setUserState(null) }

  return <AuthContext.Provider value={{ user, setUser, isLoading: isPending, signOut }}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (!context) throw new Error("useAuth must be used within an AuthProvider")
  return context
}
