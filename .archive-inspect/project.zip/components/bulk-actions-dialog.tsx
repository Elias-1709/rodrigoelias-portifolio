"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { X } from "lucide-react"
import type { Voter } from "@/lib/mock-data"

interface BulkActionsDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  selectedVoters: Voter[]
  onApply: (action: string, value: any) => void
}

export function BulkActionsDialog({ open, onOpenChange, selectedVoters, onApply }: BulkActionsDialogProps) {
  const [action, setAction] = useState<string>("")
  const [statusValue, setStatusValue] = useState<string>("")
  const [categoriaValue, setCategoriaValue] = useState<string>("")
  const [tagValue, setTagValue] = useState<string>("")
  const [tagsToAdd, setTagsToAdd] = useState<string[]>([])

  const handleApply = () => {
    if (action === "change-status" && statusValue) {
      onApply("status", statusValue)
    } else if (action === "change-categoria" && categoriaValue) {
      onApply("categoria", categoriaValue)
    } else if (action === "add-tags" && tagsToAdd.length > 0) {
      onApply("tags", tagsToAdd)
    } else if (action === "delete") {
      onApply("delete", true)
    }
    resetForm()
    onOpenChange(false)
  }

  const resetForm = () => {
    setAction("")
    setStatusValue("")
    setCategoriaValue("")
    setTagValue("")
    setTagsToAdd([])
  }

  const addTag = () => {
    if (tagValue.trim() && !tagsToAdd.includes(tagValue.trim())) {
      setTagsToAdd([...tagsToAdd, tagValue.trim()])
      setTagValue("")
    }
  }

  const removeTag = (tag: string) => {
    setTagsToAdd(tagsToAdd.filter((t) => t !== tag))
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Ações em Massa</DialogTitle>
          <DialogDescription>{selectedVoters.length} eleitores selecionados</DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Ação</Label>
            <Select value={action} onValueChange={setAction}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione uma ação" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="change-status">Alterar Status</SelectItem>
                <SelectItem value="change-categoria">Alterar Categoria</SelectItem>
                <SelectItem value="add-tags">Adicionar Tags</SelectItem>
                <SelectItem value="delete">Excluir Eleitores</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {action === "change-status" && (
            <div className="space-y-2">
              <Label>Novo Status</Label>
              <Select value={statusValue} onValueChange={setStatusValue}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Ativo</SelectItem>
                  <SelectItem value="pending">Pendente</SelectItem>
                  <SelectItem value="inactive">Inativo</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}

          {action === "change-categoria" && (
            <div className="space-y-2">
              <Label>Nova Categoria</Label>
              <Select value={categoriaValue} onValueChange={setCategoriaValue}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione a categoria" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="NM">NM 🔵</SelectItem>
                  <SelectItem value="FL">FL 🟢</SelectItem>
                  <SelectItem value="SG">SG 🟣</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}

          {action === "add-tags" && (
            <div className="space-y-2">
              <Label>Tags</Label>
              <div className="flex gap-2">
                <Input
                  value={tagValue}
                  onChange={(e) => setTagValue(e.target.value)}
                  placeholder="Digite uma tag"
                  onKeyPress={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault()
                      addTag()
                    }
                  }}
                />
                <Button type="button" onClick={addTag}>
                  Adicionar
                </Button>
              </div>
              {tagsToAdd.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-2">
                  {tagsToAdd.map((tag) => (
                    <Badge key={tag} variant="secondary" className="gap-1">
                      {tag}
                      <button onClick={() => removeTag(tag)} className="hover:text-destructive">
                        <X className="h-3 w-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              )}
            </div>
          )}

          {action === "delete" && (
            <div className="rounded-lg border border-destructive/50 bg-destructive/10 p-4">
              <p className="text-sm text-destructive">
                Atenção: Esta ação não pode ser desfeita. {selectedVoters.length} eleitores serão excluídos
                permanentemente.
              </p>
            </div>
          )}
        </div>

        <div className="flex justify-end gap-2 pt-4">
          <Button
            variant="outline"
            onClick={() => {
              resetForm()
              onOpenChange(false)
            }}
          >
            Cancelar
          </Button>
          <Button onClick={handleApply} disabled={!action} variant={action === "delete" ? "destructive" : "default"}>
            Aplicar
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
