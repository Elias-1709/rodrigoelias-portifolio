"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ChevronLeft, ChevronRight } from "lucide-react"
import type { Event } from "@/lib/mock-data"
import { cn } from "@/lib/utils"

interface CalendarGridProps {
  events: Event[]
  onEventClick: (event: Event) => void
  onDateClick: (date: Date) => void
}

export function CalendarGrid({ events, onEventClick, onDateClick }: CalendarGridProps) {
  const [currentDate, setCurrentDate] = useState(new Date())

  const monthNames = [
    "Janeiro",
    "Fevereiro",
    "Março",
    "Abril",
    "Maio",
    "Junho",
    "Julho",
    "Agosto",
    "Setembro",
    "Outubro",
    "Novembro",
    "Dezembro",
  ]

  const daysOfWeek = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"]

  const year = currentDate.getFullYear()
  const month = currentDate.getMonth()

  const firstDayOfMonth = new Date(year, month, 1)
  const lastDayOfMonth = new Date(year, month + 1, 0)
  const daysInMonth = lastDayOfMonth.getDate()
  const startDayOfWeek = firstDayOfMonth.getDay()

  const previousMonth = () => {
    setCurrentDate(new Date(year, month - 1, 1))
  }

  const nextMonth = () => {
    setCurrentDate(new Date(year, month + 1, 1))
  }

  const getEventsForDate = (day: number) => {
    const dateStr = `${year}-${String(month + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`
    return events.filter((event) => event.date === dateStr)
  }

  const isToday = (day: number) => {
    const today = new Date()
    return today.getDate() === day && today.getMonth() === month && today.getFullYear() === year
  }

  const days = []
  for (let i = 0; i < startDayOfWeek; i++) {
    days.push(<div key={`empty-${i}`} className="min-h-24 p-2 border border-border bg-muted/30" />)
  }

  for (let day = 1; day <= daysInMonth; day++) {
    const dayEvents = getEventsForDate(day)
    const today = isToday(day)

    days.push(
      <div
        key={day}
        className={cn(
          "min-h-24 p-2 border border-border bg-card hover:bg-accent/50 cursor-pointer transition-colors",
          today && "bg-primary/5 border-primary/30",
        )}
        onClick={() => onDateClick(new Date(year, month, day))}
      >
        <div className={cn("text-sm font-medium mb-1", today && "text-primary")}>{day}</div>
        <div className="space-y-1">
          {dayEvents.slice(0, 2).map((event) => (
            <div
              key={event.id}
              onClick={(e) => {
                e.stopPropagation()
                onEventClick(event)
              }}
              className={cn(
                "text-xs p-1 rounded truncate cursor-pointer",
                event.type === "meeting" && "bg-blue-100 text-blue-700 hover:bg-blue-200",
                event.type === "rally" && "bg-green-100 text-green-700 hover:bg-green-200",
                event.type === "debate" && "bg-purple-100 text-purple-700 hover:bg-purple-200",
                event.type === "visit" && "bg-orange-100 text-orange-700 hover:bg-orange-200",
                event.type === "other" && "bg-gray-100 text-gray-700 hover:bg-gray-200",
              )}
            >
              {event.time} - {event.title}
            </div>
          ))}
          {dayEvents.length > 2 && <div className="text-xs text-muted-foreground">+{dayEvents.length - 2} mais</div>}
        </div>
      </div>,
    )
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>
            {monthNames[month]} {year}
          </CardTitle>
          <div className="flex gap-2">
            <Button variant="outline" size="icon" onClick={previousMonth}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="sm" onClick={() => setCurrentDate(new Date())}>
              Hoje
            </Button>
            <Button variant="outline" size="icon" onClick={nextMonth}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-7 gap-0">
          {daysOfWeek.map((day) => (
            <div key={day} className="p-2 text-center text-sm font-medium border border-border bg-muted">
              {day}
            </div>
          ))}
          {days}
        </div>
      </CardContent>
    </Card>
  )
}
