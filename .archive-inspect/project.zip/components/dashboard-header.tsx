"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Bell, Command, LogOut, Menu, Search, Settings } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { DashboardNav } from "@/components/dashboard-nav"
import { ThemeToggle } from "@/components/theme-toggle"
import { useAuth } from "@/components/auth-provider"

export function DashboardHeader() {
  const { user, signOut } = useAuth()
  const router = useRouter()
  const [mobileOpen, setMobileOpen] = useState(false)
  const handleLogout = async () => { await signOut(); router.push("/"); router.refresh() }
  return (
    <header className="sticky top-0 z-40 border-b border-border/70 bg-background/90 backdrop-blur-xl">
      <div className="flex h-16 items-center gap-4 px-4 md:px-8">
        <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
          <SheetTrigger asChild><Button variant="ghost" size="icon" className="md:hidden"><Menu className="h-5 w-5" /><span className="sr-only">Abrir menu</span></Button></SheetTrigger>
          <SheetContent side="left" className="w-72 border-0 bg-sidebar p-0"><DashboardNav /></SheetContent>
        </Sheet>
        <div className="flex min-w-0 flex-1 items-center justify-between gap-4">
          <div className="hidden items-center gap-2 text-sm text-muted-foreground md:flex"><span className="text-foreground font-medium">Eleições 2026</span><span>/</span><span>Centro de comando</span></div>
          <div className="flex items-center gap-1 sm:gap-2">
            <Button variant="outline" className="hidden h-9 gap-2 border-border/80 text-muted-foreground sm:flex" onClick={() => window.dispatchEvent(new Event("open-command-palette"))}><Search className="h-4 w-4" /><span>Buscar</span><kbd className="ml-3 rounded border bg-muted px-1.5 py-0.5 text-[10px]">⌘ K</kbd></Button>
            <Button variant="ghost" size="icon" className="sm:hidden" onClick={() => window.dispatchEvent(new Event("open-command-palette"))}><Search className="h-4 w-4" /><span className="sr-only">Buscar</span></Button>
            <Button variant="ghost" size="icon" className="relative"><Bell className="h-4 w-4" /><span className="absolute right-2 top-2 h-1.5 w-1.5 rounded-full bg-sidebar-primary" /><span className="sr-only">Notificações</span></Button>
            <ThemeToggle />
            {user?.role === "admin" && <Button variant="ghost" size="icon" asChild><Link href="/dashboard/settings"><Settings className="h-4 w-4" /><span className="sr-only">Configurações</span></Link></Button>}
            <div className="ml-1 hidden items-center gap-2 border-l pl-3 sm:flex"><div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">{user?.name?.slice(0, 2).toUpperCase() || "AD"}</div><div className="hidden lg:block"><p className="text-xs font-semibold">{user?.name || "Administrador"}</p><p className="text-[10px] uppercase tracking-wider text-muted-foreground">{user?.role || "Admin"}</p></div></div>
            <Button variant="ghost" size="icon" onClick={handleLogout} title="Sair"><LogOut className="h-4 w-4" /><span className="sr-only">Sair</span></Button>
          </div>
        </div>
      </div>
    </header>
  )
}
