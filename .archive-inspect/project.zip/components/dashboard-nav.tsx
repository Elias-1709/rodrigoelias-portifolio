"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { useAuth } from "@/components/auth-provider"
import { BarChart3, CalendarDays, ClipboardCheck, LineChart, LockKeyhole, MessageSquareText, Search, Settings, UsersRound } from "lucide-react"

const navItems = [
  { title: "Visão geral", href: "/dashboard", icon: BarChart3 },
  { title: "Eleitores", href: "/dashboard/voters", icon: UsersRound },
  { title: "Agenda", href: "/dashboard/calendar", icon: CalendarDays },
  { title: "Tarefas", href: "/dashboard/tasks", icon: ClipboardCheck },
  { title: "Disparo", href: "/dashboard/dispatch", icon: MessageSquareText },
  { title: "Busca avançada", href: "/dashboard/search", icon: Search },
  { title: "Projeções", href: "/dashboard/projections", icon: LineChart },
  { title: "Usuários", href: "/dashboard/users", icon: UsersRound },
]

export function DashboardNav() {
  const pathname = usePathname()
  const { user } = useAuth()
  return (
    <nav aria-label="Navegação principal" className="flex h-full flex-col bg-sidebar px-3 py-5 text-sidebar-foreground">
      <div className="mb-8 flex items-center gap-3 px-3">
        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-sidebar-primary text-sidebar-primary-foreground font-black">EC</div>
        <div><p className="text-sm font-bold tracking-tight">ELECTORAL</p><p className="text-[10px] font-semibold tracking-[0.2em] text-sidebar-primary">COMMAND CENTER</p></div>
      </div>
      <p className="px-3 pb-3 text-[10px] font-bold uppercase tracking-[0.18em] text-sidebar-foreground/45">Operação</p>
      <div className="flex flex-col gap-1">
        {navItems.map(({ title, href, icon: Icon }) => {
          const active = pathname === href
          return <Link key={href} href={href} className={cn("group flex items-center gap-3 rounded-md px-3 py-2.5 text-sm font-medium transition-colors", active ? "bg-sidebar-accent text-sidebar-accent-foreground" : "text-sidebar-foreground/70 hover:bg-sidebar-accent/70 hover:text-sidebar-accent-foreground")}><Icon className={cn("h-4 w-4", active && "text-sidebar-primary")} />{title}{active && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-sidebar-primary" />}</Link>
        })}
        {user?.role === "admin" && <Link href="/dashboard/admin" className={cn("group flex items-center gap-3 rounded-md px-3 py-2.5 text-sm font-medium transition-colors", pathname === "/dashboard/admin" ? "bg-sidebar-accent text-sidebar-accent-foreground" : "text-sidebar-foreground/70 hover:bg-sidebar-accent/70 hover:text-sidebar-accent-foreground")}><LockKeyhole className={cn("h-4 w-4", pathname === "/dashboard/admin" && "text-sidebar-primary")} />Administração{pathname === "/dashboard/admin" && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-sidebar-primary" />}</Link>}
      </div>
      <div className="mt-auto border-t border-sidebar-border pt-4">
        <Link href="/dashboard/settings" className="flex items-center gap-3 rounded-md px-3 py-2.5 text-sm text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"><Settings className="h-4 w-4" />Configurações</Link>
        <p className="px-3 pt-4 text-[10px] uppercase tracking-wider text-sidebar-foreground/35">v2.4.0 · Região Sudeste</p>
      </div>
    </nav>
  )
}
