"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import type { Event } from "@/lib/mock-data"
import { Calendar, Clock, MapPin, Users, Pencil, Trash2 } from "lucide-react"

interface EventCardProps {
  event: Event
  onEdit: (event: Event) => void
  onDelete: (eventId: string) => void
}

export function EventCard({ event, onEdit, onDelete }: EventCardProps) {
  const typeLabels = {
    meeting: "Reunião",
    rally: "Caminhada",
    debate: "Debate",
    visit: "Visita",
    other: "Outro",
  }

  const statusColors = {
    scheduled: "bg-blue-100 text-blue-700",
    completed: "bg-green-100 text-green-700",
    cancelled: "bg-red-100 text-red-700",
  }

  const statusLabels = {
    scheduled: "Agendado",
    completed: "Realizado",
    cancelled: "Cancelado",
  }

  const typeColors = {
    meeting: "bg-purple-100 text-purple-700",
    rally: "bg-orange-100 text-orange-700",
    debate: "bg-indigo-100 text-indigo-700",
    visit: "bg-teal-100 text-teal-700",
    other: "bg-gray-100 text-gray-700",
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-start justify-between">
          <div className="space-y-1">
            <CardTitle className="text-lg">{event.title}</CardTitle>
            <CardDescription className="flex items-center gap-2">
              <Badge className={typeColors[event.type]}>{typeLabels[event.type]}</Badge>
              <Badge className={statusColors[event.status]}>{statusLabels[event.status]}</Badge>
            </CardDescription>
          </div>
          <div className="flex gap-1">
            <Button variant="ghost" size="icon" onClick={() => onEdit(event)}>
              <Pencil className="h-4 w-4" />
              <span className="sr-only">Editar</span>
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onDelete(event.id)}
              className="text-destructive hover:text-destructive"
            >
              <Trash2 className="h-4 w-4" />
              <span className="sr-only">Excluir</span>
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Calendar className="h-4 w-4" />
          <span>{new Date(event.date).toLocaleDateString("pt-BR")}</span>
          <Clock className="h-4 w-4 ml-2" />
          <span>{event.time}</span>
        </div>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <MapPin className="h-4 w-4" />
          <span>{event.location}</span>
        </div>
        {event.attendees > 0 && (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Users className="h-4 w-4" />
            <span>{event.attendees} participantes esperados</span>
          </div>
        )}
        {event.description && <p className="text-sm text-muted-foreground mt-2">{event.description}</p>}
      </CardContent>
    </Card>
  )
}
