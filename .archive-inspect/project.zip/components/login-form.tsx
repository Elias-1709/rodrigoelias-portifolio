"use client"

import type React from "react"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { signIn, signUp } from "@/lib/auth-client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Eye, EyeOff, ArrowRight, Loader2 } from "lucide-react"

export function LoginForm() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [remember, setRemember] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [isSignUp, setIsSignUp] = useState(false)
  const [message, setMessage] = useState("")
  const [error, setError] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  const fillDemo = () => { setEmail("admin@campanha.com"); setPassword("admin1234"); setError(""); setMessage("") }

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault(); setIsLoading(true); setError(""); setMessage("")
    try {
      const result = isSignUp ? await signUp.email({ email, password, name: email.split("@")[0] }) : await signIn.email({ email, password })
      if (result.error) {
        if (!isSignUp && email === "admin@campanha.com" && password === "admin1234") {
          const registration = await signUp.email({ email, password, name: "Administrador" })
          if (!registration.error) { router.replace("/dashboard"); router.refresh(); return }
        }
        setError(isSignUp ? "Não foi possível criar a conta. Verifique os dados." : "E-mail ou senha inválidos.")
        return
      }
      if (isSignUp) { setMessage("Conta criada. Redirecionando...") } else { router.replace("/dashboard"); router.refresh() }
    } catch { setError("Não foi possível concluir a operação. Tente novamente.") } finally { setIsLoading(false) }
  }

  return <form onSubmit={handleSubmit} className="mt-9 space-y-5">
    <div className="rounded-sm border border-[#b8e4e7] bg-[#effafb] p-3 text-xs text-[#166b78]" role="note">
      <p className="font-semibold">Acesso de teste</p>
      <p className="mt-1">Usuário: <strong>admin@campanha.com</strong></p>
      <p>Senha: <strong>admin1234</strong></p>
      <button type="button" onClick={fillDemo} className="mt-2 font-semibold underline underline-offset-2 hover:no-underline">Preencher acesso</button>
    </div>
    <div className="space-y-2"><Label htmlFor="email" className="text-xs font-medium text-[#102b45]">E-mail profissional</Label><Input id="email" type="email" autoComplete="email" value={email} onChange={(event) => setEmail(event.target.value)} required className="h-12 rounded-sm border-slate-300 bg-white px-4 text-sm shadow-none focus-visible:border-[#18788c] focus-visible:ring-[#18788c]/20" /></div>
    <div className="space-y-2"><Label htmlFor="password" className="text-xs font-medium text-[#102b45]">Senha</Label><div className="relative"><Input id="password" type={showPassword ? "text" : "password"} autoComplete={isSignUp ? "new-password" : "current-password"} value={password} onChange={(event) => setPassword(event.target.value)} required minLength={8} className="h-12 rounded-sm border-slate-300 bg-white px-4 pr-11 text-sm shadow-none focus-visible:border-[#18788c] focus-visible:ring-[#18788c]/20" /><button type="button" onClick={() => setShowPassword((value) => !value)} aria-label={showPassword ? "Ocultar senha" : "Mostrar senha"} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-[#18788c]">{showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}</button></div></div>
    {!isSignUp && <div className="flex items-center justify-between"><label className="flex items-center gap-2 text-xs text-slate-500"><input type="checkbox" checked={remember} onChange={(event) => setRemember(event.target.checked)} className="h-4 w-4 rounded-sm border-slate-300 accent-[#18788c]" />Manter conectado</label><button type="button" onClick={() => setMessage("Entre em contato com o administrador para redefinir sua senha.")} className="text-xs font-medium text-[#18788c] hover:underline">Esqueci minha senha</button></div>}
    {(error || message) && <div role={error ? "alert" : "status"} className={`border p-3 text-xs ${error ? "border-red-200 bg-red-50 text-red-700" : "border-[#b8e4e7] bg-[#effafb] text-[#166b78]"}`}>{error || message}</div>}
    <Button type="submit" disabled={isLoading} className="h-12 w-full justify-between rounded-sm bg-[#18788c] px-4 text-sm font-semibold text-white shadow-none hover:bg-[#126777]">{isLoading ? <><span>Processando...</span><Loader2 className="h-4 w-4 animate-spin" /></> : <><span>{isSignUp ? "Criar conta" : "Entrar no Command Center"}</span><ArrowRight className="h-4 w-4" /></>}</Button>
    <div className="flex items-center justify-between text-xs"><button type="button" onClick={fillDemo} className="text-slate-400 hover:text-[#18788c]">Usar acesso de demonstração</button><button type="button" onClick={() => { setIsSignUp((value) => !value); setError(""); setMessage("") }} className="font-medium text-[#18788c] hover:underline">{isSignUp ? "Já tenho uma conta" : "Primeiro acesso? Criar conta"}</button></div>
  </form>
}
