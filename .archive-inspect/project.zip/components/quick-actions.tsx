"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { UserPlus, Calendar, Search, Users } from "lucide-react"
import { useRouter } from "next/navigation"

export function QuickActions() {
  const router = useRouter()

  const actions = [
    {
      title: "Cadastrar Eleitor",
      description: "Adicione um novo apoiador",
      icon: UserPlus,
      onClick: () => router.push("/dashboard/voters"),
      color: "bg-blue-500 hover:bg-blue-600",
    },
    {
      title: "Novo Evento",
      description: "Agende uma atividade",
      icon: Calendar,
      onClick: () => router.push("/dashboard/calendar"),
      color: "bg-green-500 hover:bg-green-600",
    },
    {
      title: "Buscar Eleitores",
      description: "Encontre apoiadores",
      icon: Search,
      onClick: () => router.push("/dashboard/search"),
      color: "bg-purple-500 hover:bg-purple-600",
    },
    {
      title: "Ver Todos",
      description: "Lista completa",
      icon: Users,
      onClick: () => router.push("/dashboard/voters"),
      color: "bg-orange-500 hover:bg-orange-600",
    },
  ]

  return (
    <Card>
      <CardHeader>
        <CardTitle>Ações Rápidas</CardTitle>
        <CardDescription>Acesse rapidamente as principais funcionalidades</CardDescription>
      </CardHeader>
      <CardContent className="grid grid-cols-2 gap-3">
        {actions.map((action) => (
          <Button
            key={action.title}
            onClick={action.onClick}
            className={`h-auto flex-col items-start gap-2 p-4 ${action.color} text-white`}
          >
            <action.icon className="h-5 w-5" />
            <div className="text-left">
              <div className="font-semibold text-sm">{action.title}</div>
              <div className="text-xs opacity-90">{action.description}</div>
            </div>
          </Button>
        ))}
      </CardContent>
    </Card>
  )
}
