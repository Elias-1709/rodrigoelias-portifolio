"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { UserPlus, Calendar, UserCheck, Clock } from "lucide-react"
import { getVoters, getEvents } from "@/lib/storage"
import { useEffect, useState } from "react"

type Activity = {
  id: string
  type: "voter" | "event"
  title: string
  description: string
  timestamp: Date
  icon: any
  color: string
}

export function RecentActivity() {
  const [activities, setActivities] = useState<Activity[]>([])

  useEffect(() => {
    if (typeof window !== "undefined") {
      const voters = getVoters()
      const events = getEvents()

      const voterActivities: Activity[] = voters
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
        .slice(0, 3)
        .map((voter) => ({
          id: voter.id,
          type: "voter" as const,
          title: `Novo eleitor cadastrado`,
          description: voter.name,
          timestamp: new Date(voter.createdAt),
          icon: UserPlus,
          color: "bg-blue-500",
        }))

      const eventActivities: Activity[] = events
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
        .slice(0, 2)
        .map((event) => ({
          id: event.id,
          type: "event" as const,
          title: event.status === "completed" ? "Evento realizado" : "Evento agendado",
          description: event.title,
          timestamp: new Date(event.date),
          icon: event.status === "completed" ? UserCheck : Calendar,
          color: event.status === "completed" ? "bg-green-500" : "bg-purple-500",
        }))

      const allActivities = [...voterActivities, ...eventActivities]
        .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
        .slice(0, 5)

      setActivities(allActivities)
    }
  }, [])

  const getRelativeTime = (date: Date) => {
    const now = new Date()
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000)

    if (diffInSeconds < 60) return "Agora mesmo"
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}min atrás`
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h atrás`
    if (diffInSeconds < 2592000) return `${Math.floor(diffInSeconds / 86400)}d atrás`
    return date.toLocaleDateString("pt-BR", { day: "2-digit", month: "short" })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Atividade Recente</CardTitle>
        <CardDescription>Últimas atualizações do sistema</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {activities.length > 0 ? (
          activities.map((activity) => (
            <div key={activity.id} className="flex items-start gap-3 pb-3 border-b last:border-0 last:pb-0">
              <Avatar className={`h-9 w-9 ${activity.color}`}>
                <AvatarFallback className="bg-transparent">
                  <activity.icon className="h-4 w-4 text-white" />
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 space-y-1">
                <p className="text-sm font-medium leading-none">{activity.title}</p>
                <p className="text-sm text-muted-foreground">{activity.description}</p>
                <p className="text-xs text-muted-foreground flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  {getRelativeTime(activity.timestamp)}
                </p>
              </div>
            </div>
          ))
        ) : (
          <p className="text-sm text-muted-foreground text-center py-4">Nenhuma atividade recente</p>
        )}
      </CardContent>
    </Card>
  )
}
