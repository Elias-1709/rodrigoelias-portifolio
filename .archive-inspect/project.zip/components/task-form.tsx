"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { Task } from "@/lib/mock-data"
import { getUsers, getVoters, getEvents } from "@/lib/storage"

interface TaskFormProps {
  task?: Task
  onSubmit: (taskData: Partial<Task>) => void
  onCancel: () => void
}

export function TaskForm({ task, onSubmit, onCancel }: TaskFormProps) {
  const users = getUsers()
  const voters = getVoters()
  const events = getEvents()

  const [formData, setFormData] = useState({
    title: task?.title || "",
    description: task?.description || "",
    status: task?.status || "todo",
    priority: task?.priority || "medium",
    dueDate: task?.dueDate || "",
    assignedTo: task?.assignedTo || "",
    relatedType: task?.relatedTo?.type || "",
    relatedId: task?.relatedTo?.id || "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const assignedUser = users.find((u) => u.id === formData.assignedTo)
    let relatedTo = undefined

    if (formData.relatedType && formData.relatedId) {
      if (formData.relatedType === "voter") {
        const voter = voters.find((v) => v.id === formData.relatedId)
        if (voter) {
          relatedTo = {
            type: "voter" as const,
            id: voter.id,
            name: voter.name,
          }
        }
      } else if (formData.relatedType === "event") {
        const event = events.find((e) => e.id === formData.relatedId)
        if (event) {
          relatedTo = {
            type: "event" as const,
            id: event.id,
            name: event.title,
          }
        }
      }
    }

    onSubmit({
      title: formData.title,
      description: formData.description,
      status: formData.status as Task["status"],
      priority: formData.priority as Task["priority"],
      dueDate: formData.dueDate,
      assignedTo: formData.assignedTo,
      assignedToName: assignedUser?.name || "",
      relatedTo,
    })
  }

  const relatedOptions =
    formData.relatedType === "voter"
      ? voters.map((v) => ({ id: v.id, name: v.name }))
      : formData.relatedType === "event"
        ? events.map((e) => ({ id: e.id, name: e.title }))
        : []

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="title">Título *</Label>
        <Input
          id="title"
          value={formData.title}
          onChange={(e) => setFormData({ ...formData, title: e.target.value })}
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Descrição</Label>
        <Textarea
          id="description"
          value={formData.description}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          rows={4}
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="status">Status</Label>
          <Select value={formData.status} onValueChange={(value) => setFormData({ ...formData, status: value as Task["status"] })}>
            <SelectTrigger id="status">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todo">A Fazer</SelectItem>
              <SelectItem value="in-progress">Em Progresso</SelectItem>
              <SelectItem value="completed">Concluída</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="priority">Prioridade</Label>
          <Select value={formData.priority} onValueChange={(value) => setFormData({ ...formData, priority: value as Task["priority"] })}>
            <SelectTrigger id="priority">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="low">Baixa</SelectItem>
              <SelectItem value="medium">Média</SelectItem>
              <SelectItem value="high">Alta</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="dueDate">Data de Vencimento *</Label>
          <Input
            id="dueDate"
            type="date"
            value={formData.dueDate}
            onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })}
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="assignedTo">Atribuído a *</Label>
          <Select
            value={formData.assignedTo}
            onValueChange={(value) => setFormData({ ...formData, assignedTo: value })}
          >
            <SelectTrigger id="assignedTo">
              <SelectValue placeholder="Selecione um usuário" />
            </SelectTrigger>
            <SelectContent>
              {users.map((user) => (
                <SelectItem key={user.id} value={user.id}>
                  {user.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="relatedType">Relacionado a (opcional)</Label>
          <Select
            value={formData.relatedType}
            onValueChange={(value) => setFormData({ ...formData, relatedType: value, relatedId: "" })}
          >
            <SelectTrigger id="relatedType">
              <SelectValue placeholder="Selecione um tipo" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="none">Nenhum</SelectItem>
              <SelectItem value="voter">Eleitor</SelectItem>
              <SelectItem value="event">Evento</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {formData.relatedType && formData.relatedType !== "none" && (
          <div className="space-y-2">
            <Label htmlFor="relatedId">{formData.relatedType === "voter" ? "Eleitor" : "Evento"}</Label>
            <Select
              value={formData.relatedId}
              onValueChange={(value) => setFormData({ ...formData, relatedId: value })}
            >
              <SelectTrigger id="relatedId">
                <SelectValue placeholder="Selecione" />
              </SelectTrigger>
              <SelectContent>
                {relatedOptions.map((option) => (
                  <SelectItem key={option.id} value={option.id}>
                    {option.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}
      </div>

      <div className="flex justify-end gap-2">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancelar
        </Button>
        <Button type="submit">{task ? "Atualizar" : "Criar"} Tarefa</Button>
      </div>
    </form>
  )
}
