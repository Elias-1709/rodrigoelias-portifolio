"use client"

import type React from "react"
import { createContext, useContext, useEffect, useState } from "react"
import { getThemeSettings, saveThemeSettings, applyTheme, type Theme, type ThemeSettings } from "@/lib/theme"

interface ThemeContextType {
  settings: ThemeSettings
  setTheme: (theme: Theme) => void
  setPrimaryColor: (color: string) => void
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined)

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [settings, setSettings] = useState<ThemeSettings>(() => getThemeSettings())

  useEffect(() => {
    applyTheme(settings)

    // Listen for system theme changes
    const mediaQuery = window.matchMedia("(prefers-color-scheme: dark)")
    const handleChange = () => {
      if (settings.mode === "system") {
        applyTheme(settings)
      }
    }

    mediaQuery.addEventListener("change", handleChange)
    return () => mediaQuery.removeEventListener("change", handleChange)
  }, [settings])

  const setTheme = (theme: Theme) => {
    const newSettings = { ...settings, mode: theme }
    setSettings(newSettings)
    saveThemeSettings(newSettings)
    applyTheme(newSettings)
  }

  const setPrimaryColor = (color: string) => {
    const newSettings = { ...settings, primaryColor: color }
    setSettings(newSettings)
    saveThemeSettings(newSettings)
    applyTheme(newSettings)
  }

  return <ThemeContext.Provider value={{ settings, setTheme, setPrimaryColor }}>{children}</ThemeContext.Provider>
}

export function useTheme() {
  const context = useContext(ThemeContext)
  if (context === undefined) {
    throw new Error("useTheme must be used within a ThemeProvider")
  }
  return context
}
