"use client"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Separator } from "@/components/ui/separator"
import type { Voter } from "@/lib/mock-data"
import { Calendar, Phone, User, MessageCircle } from "lucide-react"
import { openWhatsApp } from "@/lib/whatsapp"

interface VoterDetailDialogProps {
  voter: Voter | null
  open: boolean
  onOpenChange: (open: boolean) => void
  onEdit: (voter: Voter) => void
}

export function VoterDetailDialog({ voter, open, onOpenChange, onEdit }: VoterDetailDialogProps) {
  if (!voter) return null

  const statusColors = {
    active: "bg-green-100 text-green-700",
    pending: "bg-yellow-100 text-yellow-700",
    inactive: "bg-gray-100 text-gray-700",
  }

  const statusLabels = {
    active: "Ativo",
    pending: "Pendente",
    inactive: "Inativo",
  }

  const categoriaDisplay = {
    NM: "🔵 NM",
    FL: "🟢 FL",
    SG: "🟣 SG",
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span>{voter.name}</span>
            <Badge className={statusColors[voter.status]}>{statusLabels[voter.status]}</Badge>
          </DialogTitle>
          <DialogDescription>Informações detalhadas do eleitor</DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          <div>
            <h3 className="font-semibold mb-3 flex items-center gap-2">
              <User className="h-4 w-4" />
              Dados Pessoais
            </h3>
            <div className="grid gap-3 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">CPF:</span>
                <span className="font-medium">{voter.cpf}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Data de Nascimento:</span>
                <span className="font-medium">{new Date(voter.birthDate).toLocaleDateString("pt-BR")}</span>
              </div>
            </div>
          </div>

          <Separator />

          <div>
            <h3 className="font-semibold mb-3 flex items-center gap-2">
              <Phone className="h-4 w-4" />
              Contato
            </h3>
            <div className="grid gap-3 text-sm">
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Telefone:</span>
                <div className="flex items-center gap-2">
                  <span className="font-medium">{voter.phone}</span>
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-7 gap-1 text-green-600 hover:text-green-700 border-green-200 hover:border-green-300 bg-transparent"
                    onClick={() => openWhatsApp(voter.phone, voter.name)}
                  >
                    <MessageCircle className="h-3 w-3" />
                    WhatsApp
                  </Button>
                </div>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Email:</span>
                <span className="font-medium">{voter.email || "Não informado"}</span>
              </div>
            </div>
          </div>

          <Separator />

          <div>
            <h3 className="font-semibold mb-3">Informações Eleitorais</h3>
            <div className="grid gap-3 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Zona:</span>
                <span className="font-medium">{voter.zone}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Seção:</span>
                <span className="font-medium">{voter.section}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Categoria:</span>
                <span className="font-medium">{categoriaDisplay[voter.categoria]}</span>
              </div>
            </div>
          </div>

          <Separator />

          <div>
            <h3 className="font-semibold mb-3">Tags</h3>
            <div className="flex flex-wrap gap-2">
              {voter.tags.map((tag) => (
                <Badge key={tag} variant="secondary">
                  {tag}
                </Badge>
              ))}
            </div>
          </div>

          {voter.notes && (
            <>
              <Separator />
              <div>
                <h3 className="font-semibold mb-3">Observações</h3>
                <p className="text-sm text-muted-foreground">{voter.notes}</p>
              </div>
            </>
          )}

          <Separator />

          <div>
            <h3 className="font-semibold mb-3 flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              Histórico
            </h3>
            <div className="grid gap-3 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Cadastrado em:</span>
                <span className="font-medium">{new Date(voter.createdAt).toLocaleDateString("pt-BR")}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Último contato:</span>
                <span className="font-medium">{new Date(voter.lastContact).toLocaleDateString("pt-BR")}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-end gap-2 pt-4">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Fechar
          </Button>
          <Button
            onClick={() => {
              onEdit(voter)
              onOpenChange(false)
            }}
          >
            Editar
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
