import { boolean, integer, jsonb, pgTable, text, timestamp } from "drizzle-orm/pg-core"

export const user = pgTable("user", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  emailVerified: boolean("emailVerified").notNull().default(false),
  image: text("image"),
  createdAt: timestamp("createdAt").notNull().defaultNow(),
  updatedAt: timestamp("updatedAt").notNull().defaultNow(),
  role: text("role").notNull().default("operator"),
})

export const session = pgTable("session", {
  id: text("id").primaryKey(),
  expiresAt: timestamp("expiresAt").notNull(),
  token: text("token").notNull().unique(),
  createdAt: timestamp("createdAt").notNull().defaultNow(),
  updatedAt: timestamp("updatedAt").notNull().defaultNow(),
  ipAddress: text("ipAddress"),
  userAgent: text("userAgent"),
  userId: text("userId").notNull(),
})

export const account = pgTable("account", {
  id: text("id").primaryKey(),
  accountId: text("accountId").notNull(),
  providerId: text("providerId").notNull(),
  issuer: text("issuer"),
  userId: text("userId").notNull(),
  accessToken: text("accessToken"),
  refreshToken: text("refreshToken"),
  idToken: text("idToken"),
  accessTokenExpiresAt: timestamp("accessTokenExpiresAt"),
  refreshTokenExpiresAt: timestamp("refreshTokenExpiresAt"),
  scope: text("scope"),
  password: text("password"),
  createdAt: timestamp("createdAt").notNull().defaultNow(),
  updatedAt: timestamp("updatedAt").notNull().defaultNow(),
})

export const verification = pgTable("verification", {
  id: text("id").primaryKey(),
  identifier: text("identifier").notNull(),
  value: text("value").notNull(),
  expiresAt: timestamp("expiresAt").notNull(),
  createdAt: timestamp("createdAt").defaultNow(),
  updatedAt: timestamp("updatedAt").defaultNow(),
})

export const campaignVoters = pgTable("campaign_voters", {
  id: text("id").primaryKey(), userId: text("user_id").notNull(), name: text("name").notNull(), cpf: text("cpf").notNull(), email: text("email"), phone: text("phone"), birthDate: text("birth_date"), address: jsonb("address").notNull().default({}), zone: text("zone"), section: text("section"), status: text("status").notNull().default("active"), categoria: text("categoria"), tags: jsonb("tags").notNull().default([]), notes: text("notes"), lastContact: text("last_contact"), registeredAt: text("registered_at").notNull(), createdAt: timestamp("created_at").notNull().defaultNow(), updatedAt: timestamp("updated_at").notNull().defaultNow(),
})

export const campaignEvents = pgTable("campaign_events", {
  id: text("id").primaryKey(), userId: text("user_id").notNull(), title: text("title").notNull(), description: text("description"), date: text("date").notNull(), time: text("time"), location: text("location"), status: text("status").notNull().default("scheduled"), attendees: integer("attendees").notNull().default(0), createdAt: timestamp("created_at").notNull().defaultNow(), updatedAt: timestamp("updated_at").notNull().defaultNow(),
})

export const campaignTasks = pgTable("campaign_tasks", {
  id: text("id").primaryKey(), userId: text("user_id").notNull(), title: text("title").notNull(), description: text("description"), dueDate: text("due_date"), priority: text("priority").notNull().default("medium"), status: text("status").notNull().default("pending"), assignee: text("assignee"), createdAt: timestamp("created_at").notNull().defaultNow(), updatedAt: timestamp("updated_at").notNull().defaultNow(),
})

export const campaignAuditLog = pgTable("campaign_audit_log", {
  id: text("id").primaryKey(), userId: text("user_id").notNull(), action: text("action").notNull(), entity: text("entity").notNull(), entityId: text("entity_id"), metadata: jsonb("metadata").notNull().default({}), createdAt: timestamp("created_at").notNull().defaultNow(),
})

export const campaignLeaders = pgTable("campaign_leaders", {
  id: text("id").primaryKey(), userId: text("user_id").notNull(), name: text("name").notNull(), phone: text("phone").notNull(), region: text("region").notNull(), district: text("district"), status: text("status").notNull().default("available"), notes: text("notes"), createdAt: timestamp("created_at").notNull().defaultNow(), updatedAt: timestamp("updated_at").notNull().defaultNow(),
})

export const campaignDispatches = pgTable("campaign_dispatches", {
  id: text("id").primaryKey(), userId: text("user_id").notNull(), leaderId: text("leader_id"), recipientType: text("recipient_type").notNull().default("leader"), recipientId: text("recipient_id"), recipientName: text("recipient_name").notNull(), recipientPhone: text("recipient_phone").notNull(), region: text("region").notNull(), demand: text("demand").notNull(), channel: text("channel").notNull().default("whatsapp_web"), status: text("status").notNull().default("queued"), scheduledFor: timestamp("scheduled_for"), sentAt: timestamp("sent_at"), providerMessageId: text("provider_message_id"), errorMessage: text("error_message"), createdAt: timestamp("created_at").notNull().defaultNow(), updatedAt: timestamp("updated_at").notNull().defaultNow(),
})

export const campaignWhatsappSettings = pgTable("campaign_whatsapp_settings", {
  id: text("id").primaryKey(), userId: text("user_id").notNull(), senderName: text("sender_name").notNull(), senderPhone: text("sender_phone").notNull(), apiEnabled: boolean("api_enabled").notNull().default(false), createdAt: timestamp("created_at").notNull().defaultNow(), updatedAt: timestamp("updated_at").notNull().defaultNow(),
})

export const campaignPermissions = pgTable("campaign_permissions", {
  id: text("id").primaryKey(), userId: text("user_id").notNull(), grantedBy: text("granted_by").notNull(), resource: text("resource").notNull(), grantedAt: timestamp("granted_at").notNull().defaultNow(),
})
