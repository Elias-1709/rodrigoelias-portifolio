// Mock data for the political campaign management system

export interface Voter {
  id: string
  name: string
  cpf: string
  email: string
  phone: string
  birthDate: string
  address: {
    street: string
    number: string
    neighborhood: string
    city: string
    state: string
    zipCode: string
  }
  zone: string
  section: string
  status: "active" | "pending" | "inactive"
  categoria: "NM" | "FL" | "SG"
  tags: string[]
  notes: string
  lastContact: string
  createdAt: string
  registeredAt: string
}

export interface Event {
  id: string
  title: string
  type: "meeting" | "rally" | "debate" | "visit" | "other"
  date: string
  time: string
  location: string
  description: string
  attendees: number
  status: "scheduled" | "completed" | "cancelled"
}

export interface Campaign {
  id: string
  name: string
  candidate: string
  party: string
  position: string
  year: number
  status: "active" | "completed"
}

export interface User {
  id: string
  name: string
  email: string
  password?: string
  role: "admin" | "coordinator" | "volunteer" | "operator"
}

export interface Task {
  id: string
  title: string
  description: string
  status: "todo" | "in-progress" | "completed"
  priority: "low" | "medium" | "high"
  dueDate: string
  assignedTo: string // user id
  assignedToName: string // user name for display
  relatedTo?: {
    type: "voter" | "event"
    id: string
    name: string
  }
  createdAt: string
  completedAt?: string
}

export const mockVoters: Voter[] = [
  {
    id: "1",
    name: "Maria Silva Santos",
    cpf: "123.456.789-00",
    email: "maria.silva@email.com",
    phone: "(11) 98765-4321",
    birthDate: "1985-03-15",
    address: {
      street: "Rua das Flores",
      number: "123",
      neighborhood: "Centro",
      city: "São Paulo",
      state: "SP",
      zipCode: "01000-000",
    },
    zone: "001",
    section: "0123",
    status: "active",
    categoria: "NM",
    tags: ["liderança comunitária", "educação"],
    notes: "Muito engajada em questões educacionais",
    lastContact: "2024-01-15",
    createdAt: "2023-12-01",
    registeredAt: "2023-11-30",
  },
  {
    id: "2",
    name: "João Pedro Oliveira",
    cpf: "987.654.321-00",
    email: "joao.oliveira@email.com",
    phone: "(11) 91234-5678",
    birthDate: "1978-07-22",
    address: {
      street: "Avenida Paulista",
      number: "1000",
      neighborhood: "Bela Vista",
      city: "São Paulo",
      state: "SP",
      zipCode: "01310-000",
    },
    zone: "002",
    section: "0234",
    status: "active",
    categoria: "FL",
    tags: ["empresário", "meio ambiente"],
    notes: "Interessado em políticas ambientais",
    lastContact: "2024-01-18",
    createdAt: "2023-11-15",
    registeredAt: "2023-11-14",
  },
  {
    id: "3",
    name: "Ana Carolina Ferreira",
    cpf: "456.789.123-00",
    email: "ana.ferreira@email.com",
    phone: "(11) 99876-5432",
    birthDate: "1992-11-08",
    address: {
      street: "Rua da Consolação",
      number: "500",
      neighborhood: "Consolação",
      city: "São Paulo",
      state: "SP",
      zipCode: "01302-000",
    },
    zone: "001",
    section: "0145",
    status: "pending",
    categoria: "SG",
    tags: ["saúde", "jovem"],
    notes: "Profissional da saúde, primeira vez votando",
    lastContact: "2024-01-10",
    createdAt: "2024-01-05",
    registeredAt: "2024-01-04",
  },
  {
    id: "4",
    name: "Carlos Eduardo Costa",
    cpf: "321.654.987-00",
    email: "carlos.costa@email.com",
    phone: "(11) 97654-3210",
    birthDate: "1965-04-30",
    address: {
      street: "Rua Augusta",
      number: "2000",
      neighborhood: "Jardins",
      city: "São Paulo",
      state: "SP",
      zipCode: "01304-000",
    },
    zone: "003",
    section: "0356",
    status: "active",
    categoria: "NM",
    tags: ["aposentado", "transporte"],
    notes: "Defensor de melhorias no transporte público",
    lastContact: "2024-01-20",
    createdAt: "2023-10-20",
    registeredAt: "2023-10-19",
  },
  {
    id: "5",
    name: "Juliana Rodrigues Lima",
    cpf: "789.123.456-00",
    email: "juliana.lima@email.com",
    phone: "(11) 96543-2109",
    birthDate: "1988-09-12",
    address: {
      street: "Rua Vergueiro",
      number: "3000",
      neighborhood: "Vila Mariana",
      city: "São Paulo",
      state: "SP",
      zipCode: "04101-000",
    },
    zone: "002",
    section: "0267",
    status: "active",
    categoria: "FL",
    tags: ["professor", "cultura"],
    notes: "Professora universitária, engajada em projetos culturais",
    lastContact: "2024-01-22",
    createdAt: "2023-12-10",
    registeredAt: "2023-12-09",
  },
]

export const mockEvents: Event[] = [
  {
    id: "1",
    title: "Reunião com Líderes Comunitários",
    type: "meeting",
    date: "2024-02-01",
    time: "14:00",
    location: "Centro Comunitário - Centro",
    description: "Discussão sobre prioridades do bairro",
    attendees: 25,
    status: "scheduled",
  },
  {
    id: "2",
    title: "Caminhada no Bairro",
    type: "rally",
    date: "2024-02-05",
    time: "09:00",
    location: "Praça da República",
    description: "Caminhada de apresentação da campanha",
    attendees: 150,
    status: "scheduled",
  },
  {
    id: "3",
    title: "Debate sobre Educação",
    type: "debate",
    date: "2024-02-10",
    time: "19:00",
    location: "Auditório Municipal",
    description: "Debate com especialistas em educação",
    attendees: 80,
    status: "scheduled",
  },
  {
    id: "4",
    title: "Visita à Feira Livre",
    type: "visit",
    date: "2024-01-20",
    time: "08:00",
    location: "Feira da Vila Mariana",
    description: "Conversa com comerciantes e moradores",
    attendees: 45,
    status: "completed",
  },
]

export const mockCampaign: Campaign = {
  id: "1",
  name: "Campanha 2024",
  candidate: "José Almeida",
  party: "Partido da Mudança",
  position: "Vereador",
  year: 2024,
  status: "active",
}

export const mockAnalytics = {
  totalVoters: 1247,
  activeVoters: 892,
  pendingVoters: 245,
  inactiveVoters: 110,
  votersByZone: [
    { zone: "001", count: 425 },
    { zone: "002", count: 389 },
    { zone: "003", count: 287 },
    { zone: "004", count: 146 },
  ],
  votersByStatus: [
    { status: "Ativos", count: 892, percent: 0.715 },
    { status: "Pendentes", count: 245, percent: 0.196 },
    { status: "Inativos", count: 110, percent: 0.088 },
  ],
  voterGrowth: [
    { month: "Set", count: 234 },
    { month: "Out", count: 456 },
    { month: "Nov", count: 678 },
    { month: "Dez", count: 892 },
    { month: "Jan", count: 1247 },
  ],
  upcomingEvents: 3,
  completedEvents: 12,
}
