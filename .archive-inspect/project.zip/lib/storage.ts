// Real data persistence using localStorage

import type { Voter, Event, Campaign, User, Task } from "@/lib/mock-data"

const STORAGE_KEYS = {
  VOTERS: "campaign_voters",
  EVENTS: "campaign_events",
  CAMPAIGN: "campaign_info",
  USERS: "campaign_users",
  TASKS: "campaign_tasks", // Added tasks storage key
}

// Initialize with some sample data if empty
const initialVoters: Voter[] = [
  {
    id: "1",
    name: "Maria Silva Santos",
    cpf: "123.456.789-00",
    email: "maria.silva@email.com",
    phone: "(11) 98765-4321",
    birthDate: "1985-03-15",
    address: {
      street: "Rua das Flores",
      number: "123",
      neighborhood: "Centro",
      city: "São Paulo",
      state: "SP",
      zipCode: "01000-000",
    },
    zone: "001",
    section: "0123",
    status: "active",
    categoria: "NM",
    tags: ["liderança comunitária", "educação"],
    notes: "Muito engajada em questões educacionais",
    lastContact: "2024-01-15",
    createdAt: "2023-12-01",
    registeredAt: "2023-12-01",
  },
  {
    id: "2",
    name: "João Pedro Oliveira",
    cpf: "987.654.321-00",
    email: "joao.oliveira@email.com",
    phone: "(11) 91234-5678",
    birthDate: "1978-07-22",
    address: {
      street: "Avenida Paulista",
      number: "1000",
      neighborhood: "Bela Vista",
      city: "São Paulo",
      state: "SP",
      zipCode: "01310-000",
    },
    zone: "002",
    section: "0234",
    status: "active",
    categoria: "FL",
    tags: ["empresário", "meio ambiente"],
    notes: "Interessado em políticas ambientais",
    lastContact: "2024-01-18",
    createdAt: "2023-11-15",
    registeredAt: "2023-11-15",
  },
  {
    id: "3",
    name: "Ana Carolina Ferreira",
    cpf: "456.789.123-00",
    email: "ana.ferreira@email.com",
    phone: "(11) 99876-5432",
    birthDate: "1992-11-08",
    address: {
      street: "Rua da Consolação",
      number: "500",
      neighborhood: "Consolação",
      city: "São Paulo",
      state: "SP",
      zipCode: "01302-000",
    },
    zone: "001",
    section: "0145",
    status: "pending",
    categoria: "SG",
    tags: ["saúde", "jovem"],
    notes: "Profissional da saúde, primeira vez votando",
    lastContact: "2024-01-10",
    createdAt: "2024-01-05",
    registeredAt: "2024-01-05",
  },
]

const initialUsers: User[] = [
  {
    id: "1",
    name: "Administrador",
    email: "admin@campanha.com",
    password: "admin",
    role: "admin",
  },
]

// Voters
export function getVoters(): Voter[] {
  if (typeof window === "undefined") return []
  const stored = localStorage.getItem(STORAGE_KEYS.VOTERS)
  if (!stored) {
    localStorage.setItem(STORAGE_KEYS.VOTERS, JSON.stringify(initialVoters))
    return initialVoters
  }
  return JSON.parse(stored)
}

export function saveVoter(voter: Voter): void {
  const voters = getVoters()
  const index = voters.findIndex((v) => v.id === voter.id)
  if (index >= 0) {
    voters[index] = voter
  } else {
    voters.push(voter)
  }
  localStorage.setItem(STORAGE_KEYS.VOTERS, JSON.stringify(voters))
}

export function deleteVoter(id: string): void {
  const voters = getVoters().filter((v) => v.id !== id)
  localStorage.setItem(STORAGE_KEYS.VOTERS, JSON.stringify(voters))
}

// Events
export function getEvents(): Event[] {
  if (typeof window === "undefined") return []
  const stored = localStorage.getItem(STORAGE_KEYS.EVENTS)
  return stored ? JSON.parse(stored) : []
}

export function saveEvent(event: Event): void {
  const events = getEvents()
  const index = events.findIndex((e) => e.id === event.id)
  if (index >= 0) {
    events[index] = event
  } else {
    events.push(event)
  }
  localStorage.setItem(STORAGE_KEYS.EVENTS, JSON.stringify(events))
}

export function deleteEvent(id: string): void {
  const events = getEvents().filter((e) => e.id !== id)
  localStorage.setItem(STORAGE_KEYS.EVENTS, JSON.stringify(events))
}

// Campaign
export function getCampaign(): Campaign | null {
  if (typeof window === "undefined") return null
  const stored = localStorage.getItem(STORAGE_KEYS.CAMPAIGN)
  return stored ? JSON.parse(stored) : null
}

export function saveCampaign(campaign: Campaign): void {
  localStorage.setItem(STORAGE_KEYS.CAMPAIGN, JSON.stringify(campaign))
}

// Users
export function getUsers(): User[] {
  if (typeof window === "undefined") return []
  const stored = localStorage.getItem(STORAGE_KEYS.USERS)
  if (!stored) {
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(initialUsers))
    return initialUsers
  }
  return JSON.parse(stored)
}

export function saveUser(user: User): void {
  const users = getUsers()
  const index = users.findIndex((u) => u.id === user.id)
  if (index >= 0) {
    users[index] = user
  } else {
    users.push(user)
  }
  localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users))
}

export function deleteUser(id: string): void {
  const users = getUsers().filter((u) => u.id !== id)
  localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users))
}

// Tasks
export function getTasks(): Task[] {
  if (typeof window === "undefined") return []
  const stored = localStorage.getItem(STORAGE_KEYS.TASKS)
  return stored ? JSON.parse(stored) : []
}

export function saveTask(task: Task): void {
  const tasks = getTasks()
  const index = tasks.findIndex((t) => t.id === task.id)
  if (index >= 0) {
    tasks[index] = task
  } else {
    tasks.push(task)
  }
  localStorage.setItem(STORAGE_KEYS.TASKS, JSON.stringify(tasks))
}

export function deleteTask(id: string): void {
  const tasks = getTasks().filter((t) => t.id !== id)
  localStorage.setItem(STORAGE_KEYS.TASKS, JSON.stringify(tasks))
}

// Analytics helpers
export function calculateGrowthPercentage(): number {
  const voters = getVoters()
  const now = new Date()
  const firstDayOfMonth = new Date(now.getFullYear(), now.getMonth(), 1)
  const firstDayOfLastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1)

  const thisMonthCount = voters.filter((v) => new Date(v.registeredAt) >= firstDayOfMonth).length

  const lastMonthCount = voters.filter(
    (v) => new Date(v.registeredAt) >= firstDayOfLastMonth && new Date(v.registeredAt) < firstDayOfMonth,
  ).length

  if (lastMonthCount === 0) return thisMonthCount > 0 ? 100 : 0
  return ((thisMonthCount - lastMonthCount) / lastMonthCount) * 100
}

export function getVotersByCategory() {
  const voters = getVoters()
  const nmCount = voters.filter((v) => v.categoria === "NM").length
  const flCount = voters.filter((v) => v.categoria === "FL").length
  const sgCount = voters.filter((v) => v.categoria === "SG").length

  return [
    { categoria: "NM", label: "NM 🔵", count: nmCount },
    { categoria: "FL", label: "FL 🟢", count: flCount },
    { categoria: "SG", label: "SG 🟣", count: sgCount },
  ]
}

export function getVotersByStatus() {
  const voters = getVoters()
  const activeCount = voters.filter((v) => v.status === "active").length
  const pendingCount = voters.filter((v) => v.status === "pending").length
  const inactiveCount = voters.filter((v) => v.status === "inactive").length

  return { active: activeCount, pending: pendingCount, inactive: inactiveCount }
}
