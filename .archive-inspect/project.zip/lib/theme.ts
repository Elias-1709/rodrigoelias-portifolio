"use client"

export type Theme = "light" | "dark" | "system"

export interface ThemeSettings {
  mode: Theme
  primaryColor: string
}

const THEME_STORAGE_KEY = "campaign-theme-settings"

export function getThemeSettings(): ThemeSettings {
  if (typeof window === "undefined") {
    return { mode: "system", primaryColor: "oklch(0.45 0.19 252)" }
  }

  const stored = localStorage.getItem(THEME_STORAGE_KEY)
  if (stored) {
    return JSON.parse(stored)
  }

  return { mode: "system", primaryColor: "oklch(0.45 0.19 252)" }
}

export function saveThemeSettings(settings: ThemeSettings) {
  if (typeof window === "undefined") return
  localStorage.setItem(THEME_STORAGE_KEY, JSON.stringify(settings))
}

export function applyTheme(settings: ThemeSettings) {
  if (typeof window === "undefined") return

  const root = document.documentElement

  // Apply theme mode
  if (settings.mode === "dark") {
    root.classList.add("dark")
  } else if (settings.mode === "light") {
    root.classList.remove("dark")
  } else {
    // System preference
    const isDark = window.matchMedia("(prefers-color-scheme: dark)").matches
    if (isDark) {
      root.classList.add("dark")
    } else {
      root.classList.remove("dark")
    }
  }

  // Apply primary color
  root.style.setProperty("--color-primary", settings.primaryColor)
  root.style.setProperty("--color-chart-1", settings.primaryColor)
  root.style.setProperty("--color-sidebar-primary", settings.primaryColor)
}
