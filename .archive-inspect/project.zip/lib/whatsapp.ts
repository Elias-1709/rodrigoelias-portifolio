export function formatPhoneForWhatsApp(phone: string): string {
  // Remove all non-numeric characters
  const cleaned = phone.replace(/\D/g, "")

  // Add country code if not present (55 for Brazil)
  if (!cleaned.startsWith("55")) {
    return `55${cleaned}`
  }

  return cleaned
}

export function openWhatsApp(phone: string, voterName: string, campaignName = "nossa campanha") {
  const formattedPhone = formatPhoneForWhatsApp(phone)
  const message = encodeURIComponent(
    `Olá ${voterName}! Tudo bem? Sou da ${campaignName}. Gostaria de conversar com você sobre nossas propostas e saber como podemos ajudar nossa comunidade.`,
  )

  const url = `https://wa.me/${formattedPhone}?text=${message}`
  window.open(url, "_blank")
}
